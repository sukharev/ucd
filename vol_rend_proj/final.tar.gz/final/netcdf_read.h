
#ifndef NETCDF_READ
#define NETCDF_READ

//#include <stdio.h>
#include <string>
#include <netcdf.h>
#include <fstream>
#include <iostream>
#include <assert.h>
#include <vector>
#include <algorithm>
#include <map>

#define MAX_PATH    512
#define MAX_VARS	20
#define SEARCH_DIM 	4  // we are olny interested in data with SEARCH_DIM number of dimensions	

//#define MAX_VAR		5
//#define SAMPLE	20
using namespace std;

struct NetCFD_dim
{
	char dim_name[NC_MAX_NAME];
	int length;
	int query_start;
	int query_count;
};

struct NetCFD_var
{
	NetCFD_var(){}
	~NetCFD_var(){}

	char var_name[NC_MAX_NAME];
	nc_type rh_type;                  /* variable type */
	int rh_ndims;                      /* number of dims */
	int rh_dimids[NC_MAX_VAR_DIMS];    /* dimension ids */
	NetCFD_dim * dim[NC_MAX_VAR_DIMS]; 
	int rh_natts;                      /* number of attributes */
	int temp_varid; 
	size_t* start;
    size_t* count;
	int total_size;
	bool time_dep;

	//order: only used if var is a dim, default value is -1 for all other vars
	int order;
	//axis only used for 1-dim vardims, default '\0'
	char axis;
};

#define ANY_DIM		0
struct Filter
{
	Filter()
	{
		m_exclude_str[0] = '\0';
		m_include_str[0] = '\0';
		m_dim = ANY_DIM;
	}

	int m_dim;
	char m_exclude_str[MAX_PATH];
	char m_include_str[MAX_PATH];
};

class NetCDF
{
public:
	NetCDF(char* filename);
	~NetCDF();
	int load_header();
	int read_var(NetCFD_var *var);

	// returns number of variables and array of variable names
	char** get_varnames(/*out*/ int *num, int dim = SEARCH_DIM);
	int get_num_timesteps(char* name);
	NetCFD_var* get_varinfo(char* name, Filter* fltr = NULL);
	NetCFD_var* get_varinfo_int(int index, Filter* fltr = NULL);
	
	// caller needs to pass fully allocated buffer to hold the data

	//wrapper on top next get_vardata_impl

	int get_vardata(char* index, 
						int time_in, 
						int time_out, 
						int start_var, 
						int fraction,
						/* out */char** data,
						bool bFullSize = false);
	int get_vardata_int(int index, 
						int time_in, 
						int time_out, 
						int start_var, 
						int fraction, 
						/* out */char** data,
						bool bFullSize = false);



	// caller needs to pass fully allocated buffer to hold the data

	int get_vardata_impl(NetCFD_var *var, 
		int time_in, 
		int time_out, 
		int start_var, 
		int fraction,
		/* out */char** data,
		bool bFullSize = false);

	int get_varindices();
	int get_var_size(int index);
	int get_var_size(char* name);

	
	int get_num_vars() 
	{ 
		return m_nvars; 
	}
	// return the map from index of 
	//map<int,int> get_ind_map(int dim);

private:
	int m_ncid;
	int m_ndims;							//number of all dimesions
	int m_nvars;
	char* m_dim_name_arr[NC_MAX_VAR_DIMS];				//dimensions length
	size_t m_dim_length_arr[NC_MAX_VAR_DIMS];			//dimensions name
	char m_filename[MAX_PATH];			//netCDF filename (ext .nc)
	NetCFD_var* m_var_arr[MAX_VARS];
	map<string, int> m_Nd_var;
	int m_Nd_var_num;
	bool m_init;
};


//TODO: pay attention to lifespan of this class
//pointer to instance of class NetCDF should NOT be deallocated while 
//the instance of this class is still around
//implement mechanism to enforce this or redesign the whole structure.
class NetCDFUtils
{
public:
	NetCDFUtils(NetCDF* netcdf, Filter* fltr = NULL) { 
		m_fltr = fltr;
		m_netcdf = netcdf; 
		m_pdata_arr = NULL;
		
		m_lenX = 1;
		m_lenY = 1;
		names = NULL;
		dim_min = NULL;
		dim_max = NULL;
		Init();
	}

	~NetCDFUtils() {
		Clean();
		if(m_varlist)
			delete m_varlist;
	}
	
	void Clean(){
		if(m_pdata_arr)
			delete [] m_pdata_arr;
		if(names)
			delete names;
		if(dim_min)
			delete dim_min;
		if(dim_max)
			delete dim_max;
		if(m_size)
			delete m_size;
	}

	void Init() {
		int num = m_netcdf->get_num_vars();
		m_num = 0; 

		// get all variables that satisfy conditions in m_fltr
		m_varlist = new NetCFD_var*[num];
		for(int i=0; i < num; i++){
			if(m_varlist[m_num] = m_netcdf->get_varinfo_int(i,m_fltr)){
				//m_map[m_num] = i;
				m_mapvarname[m_varlist[m_num]->var_name] = m_num;
				m_num++;
			}
			else{
				m_varlist[m_num] = NULL;
			}
		}
		
		// get all varaibles that describe dimesions of previous vars.
		num = m_num;
		int j = 0;
		for(int i=0;i < num; i++){
			j = 0;
			while(	(j < m_varlist[i]->rh_ndims) && 
					(m_varlist[i]->rh_ndims > 1)) {
				char* dimname = m_varlist[i]->dim[j]->dim_name;
				if(	strcmp(dimname,"time")!=0 &&
					/*strcmp(dimname,"zt_ocean")!=0 &&*/
					m_mapvarname.find(dimname) == m_mapvarname.end()){
					
					m_varlist[m_num] = m_netcdf->get_varinfo(dimname);
					if(m_varlist[m_num]){
						m_varlist[m_num]->order = m_num - num;
						m_mapvarname[m_varlist[m_num]->var_name] = m_num;
						m_num++;
					}
				}
				j++;
			}
		}

		NetCFD_var* varX = m_netcdf->get_varinfo("xt_ocean");
		NetCFD_var* varY = m_netcdf->get_varinfo("yt_ocean");
		int new_lenX = varX->dim[0]->query_count - varX->dim[0]->query_start;
		int new_lenY = varY->dim[0]->query_count - varY->dim[0]->query_start;
		if(new_lenX >0)
			m_lenX = new_lenX;
		if(new_lenY >0)
			m_lenY = new_lenY;
	}
public:
	int GetCoordPosition(int item, int index);
	int get_num_vars() { return m_num;}

	float** ReadVarData(int time_in, int count_in, bool bnew, int SAMPLE = 1);
	void SampleData(float* data, float* sample_data, int size, int fraction, char* varname, bool bDim);
	//float UpdateSampleData(float* sample_data, int size, char* varname, float min, float max);

	// new_start in %
	// new_count in %
	bool ChangeDataSize(int new_start, int new_count, char axis, int* out_count = NULL);
	int GetDimDataIndex(int index, NetCFD_var* var, char* dimname);

public:

	NetCDF* m_netcdf;
	float** m_pdata_arr;
	float* dim_min;
	float* dim_max;
	char** names;
	int m_num;
	int* m_size;
	NetCFD_var** m_varlist;
	Filter* m_fltr;
	//map<int, int> m_map;
	map<string, int> m_mapvarname;

	int m_lenX;
	int m_lenY;
};

/*
...reading netcdf data arrays...

for (int z = 0; z < m_vSize[2] / 2; z++)
    for (int y = 0; y < m_vSize[1]; y++) 
        for (int x = 0; x < m_vSize[0]; x++) {
             int org_id = x + y * m_vSize[0] + z * m_vSize[0] * m_vSize[1];
		}
*/
#endif //NETCDF_READ
