//
// C++ Implementation: cxvolume
//
// Description: 
//
//
// Author: Hongfeng Yu <hfyu@ucdavis.edu>, (C) 2006
//
// Copyright: See COPYING file that comes with this distribution
//
//

#include <iostream>
#include <fstream>
#include <string>
#include "GL/glew.h"
#include <FL/glut.H>
#include "cxvolume.h"
#include "cxparameters.h"
#include "shader.h"
#include "winvisview.h"
#include "winsliceview.h"
#include "cxmatrix_c.h"
//#include <unistd.h>
#include <iomanip>
#include <sstream>
#include <cmath>

extern "C" {
#include <udunits.h>
}

using namespace std;

void slerp(float * qa, float * qb, float * qm, double t) {
    
    // Calculate angle between them.
    double cosHalfTheta = qa[3] * qb[3] + qa[0] * qb[0] + qa[1] * qb[1] + qa[2] * qb[2];
    
    // if qa=qb or qa=-qb then theta = 0 and we can return qa
    if (abs(cosHalfTheta) >= 1.0){
        qm[3] = qa[3]; qm[0] = qa[0]; qm[1] = qa[1]; qm[2] = qa[2];
        return;
    }
    // Calculate temporary values.
    double halfTheta = acos(cosHalfTheta);
    double sinHalfTheta = sqrt(1.0 - cosHalfTheta*cosHalfTheta);
    // if theta = 180 degrees then result is not fully defined
    // we could rotate around any axis normal to qa or qb
    if (fabs(sinHalfTheta) < 0.001){ // fabs is floating point absolute
        qm[3] = (qa[3] * 0.5 + qb[3] * 0.5);
        qm[0] = (qa[0] * 0.5 + qb[0] * 0.5);
        qm[1] = (qa[1] * 0.5 + qb[1] * 0.5);
        qm[2] = (qa[2] * 0.5 + qb[2] * 0.5);
        return;
    }
    double ratioA = sin((1 - t) * halfTheta) / sinHalfTheta;
    double ratioB = sin(t * halfTheta) / sinHalfTheta; 
    //calculate Quaternion.
    qm[3] = (qa[3] * ratioA + qb[3] * ratioB);
    qm[0] = (qa[0] * ratioA + qb[0] * ratioB);
    qm[1] = (qa[1] * ratioA + qb[1] * ratioB);
    qm[2] = (qa[2] * ratioA + qb[2] * ratioB);    
}

cxVisStatus::cxVisStatus()
{
    m_bDrawAxes = true;        
    m_bDrawFrame = true;
    m_bDrawVolume = true;
    m_vRangeMin = cx3DVector(0, 0, 0);
    //m_vRangeMin = cx3DVector(0, 0.5, 0);
    m_vRangeMax = cx3DVector(1, 1, 1);
    m_fLightPar[0] = 0.1;
    m_fLightPar[1] = 0.9;
    m_fLightPar[2] = 0.6;
    m_fLightPar[3] = 20.0;
    m_fSampleSpacing = 1.0/128.0;
    m_fSlicePosX = 0;
    m_fSlicePosY = 0;
    m_fSlicePosZ = 0;
    m_fShiftDis = 0;
}

cxVisStatus::~cxVisStatus()
{
}

void cxVisStatus::Copy(cxVisStatus * pVisStatus)
{
    assert(pVisStatus);
    
    memcpy(m_Colors, pVisStatus->m_Colors, sizeof(cxColor) * TF_SIZE);
    
    m_vTFButtonSettings.clear();
    int size = pVisStatus->m_vTFButtonSettings.size();
    for ( int i = 0; i < size; i++)
        m_vTFButtonSettings.push_back(pVisStatus->m_vTFButtonSettings[i]);
        
    m_vTFLineSettings.clear();
    size = pVisStatus->m_vTFLineSettings.size();
    for ( int i = 0; i < size; i++)
        m_vTFLineSettings.push_back(pVisStatus->m_vTFLineSettings[i]);
    
    m_bDrawAxes = pVisStatus->m_bDrawAxes;
    
    m_bDrawFrame = pVisStatus->m_bDrawFrame;
    
    m_bDrawVolume = pVisStatus->m_bDrawVolume;
    
    m_vRangeMin = pVisStatus->m_vRangeMin;
    
    m_vRangeMax = pVisStatus->m_vRangeMax;
    
    memcpy(m_fLightPar, pVisStatus->m_fLightPar, sizeof(float) * 4);
    
    m_fSampleSpacing = pVisStatus->m_fSampleSpacing;
    
    m_fSlicePosX = pVisStatus->m_fSlicePosX;
    
    m_fSlicePosY = pVisStatus->m_fSlicePosY;
    
    m_fSlicePosZ = pVisStatus->m_fSlicePosZ;
    
    m_fShiftDis = pVisStatus->m_fShiftDis;
    
    memcpy(m_curquat, pVisStatus->m_curquat, sizeof(float) * 4);
    m_scale = pVisStatus->m_scale;
    m_deltax = pVisStatus->m_deltax;
    m_deltay = pVisStatus->m_deltay;
}


void cxVisStatus::Interpolate(cxVisStatus * pPrev, cxVisStatus * pNext, float weight)
{
    assert(pPrev);
    assert(pNext);
    
    if (weight < 0.5)
        Copy(pNext);
    else
        Copy(pPrev);
        
    for ( int i = 0; i < TF_SIZE; i++) {
        m_Colors[i].r() = pPrev->m_Colors[i].r() * weight + pNext->m_Colors[i].r() * ( 1.0 - weight);
        m_Colors[i].g() = pPrev->m_Colors[i].g() * weight + pNext->m_Colors[i].g() * ( 1.0 - weight);
        m_Colors[i].b() = pPrev->m_Colors[i].b() * weight + pNext->m_Colors[i].b() * ( 1.0 - weight);
        m_Colors[i].a() = pPrev->m_Colors[i].a() * weight + pNext->m_Colors[i].a() * ( 1.0 - weight);
    }
    
    m_vRangeMin = pPrev->m_vRangeMin * weight + pNext->m_vRangeMin * ( 1.0 - weight);
    
    m_vRangeMax = pPrev->m_vRangeMax * weight + pNext->m_vRangeMax * ( 1.0 - weight);
    
    for ( int i = 0; i < 4; i++) {
        m_fLightPar[i] = pPrev->m_fLightPar[i] * weight + pNext->m_fLightPar[i] * (1.0 - weight);
    }
    
    m_fSampleSpacing = pPrev->m_fSampleSpacing * weight + pNext->m_fSampleSpacing * ( 1.0 - weight);
    
    m_fSlicePosX = pPrev->m_fSlicePosX * weight + pNext->m_fSlicePosX * ( 1.0 - weight);
            
    m_fSlicePosY = pPrev->m_fSlicePosY * weight + pNext->m_fSlicePosY * ( 1.0 - weight);
    
    m_fSlicePosZ = pPrev->m_fSlicePosZ * weight + pNext->m_fSlicePosZ * ( 1.0 - weight);
    
    m_fShiftDis = pPrev->m_fShiftDis * weight + pNext->m_fShiftDis * ( 1.0 - weight);

    /* slerp interpolation of two quaternion rotations*/
    slerp(pPrev->m_curquat, pNext->m_curquat, m_curquat, 1.0 - weight);
    
    
    m_scale = pPrev->m_scale * weight + pNext->m_scale * ( 1.0 - weight);
    
    m_deltax = pPrev->m_deltax * weight + pNext->m_deltax * ( 1.0 - weight);
    
    m_deltay = pPrev->m_deltay * weight + pNext->m_deltay * ( 1.0 - weight);
}

void cxVisStatus::WriteToFile()
{
    char filename[1024];
#ifdef MULTI_VARIABLES
    sprintf(filename, "ctrlstatus%d.cfg", m_nVolumeID);
#else
    sprintf(filename, "ctrlstatus.cfg");
#endif

    ofstream outf(filename);
    assert(outf);
    
    
    outf.write(reinterpret_cast<char *>(m_Colors), sizeof(cxColor)*TF_SIZE);    
    outf.write(reinterpret_cast<char *>(m_fLightPar), sizeof(float) * 4);
    outf.write(reinterpret_cast<char *>(&m_fSampleSpacing), sizeof(float));
    outf.write(reinterpret_cast<char *>(m_curquat), sizeof(float)*4);
    outf.write(reinterpret_cast<char *>(&m_scale), sizeof(float));
    outf.write(reinterpret_cast<char *>(&m_deltax), sizeof(float));
    outf.write(reinterpret_cast<char *>(&m_deltay), sizeof(float));
    outf.write(reinterpret_cast<char *>(&m_fShiftDis), sizeof(float));
    
    outf.close();
}

void cxVisStatus::ReadFromFile()
{
    char filename[1024];
#ifdef MULTI_VARIABLES
    sprintf(filename, "ctrlstatus%d.cfg", m_nVolumeID);
#else
    sprintf(filename, "ctrlstatus.cfg");
#endif

    ifstream inf(filename);
    
    if (!inf)
        return;
        
    inf.read(reinterpret_cast<char *>(m_Colors), sizeof(cxColor)*TF_SIZE);    
    inf.read(reinterpret_cast<char *>(m_fLightPar), sizeof(float) * 4);
    inf.read(reinterpret_cast<char *>(&m_fSampleSpacing), sizeof(float));
    inf.read(reinterpret_cast<char *>(m_curquat), sizeof(float)*4);
    inf.read(reinterpret_cast<char *>(&m_scale), sizeof(float));
    inf.read(reinterpret_cast<char *>(&m_deltax), sizeof(float));
    inf.read(reinterpret_cast<char *>(&m_deltay), sizeof(float));
    inf.read(reinterpret_cast<char *>(&m_fShiftDis), sizeof(float));
    
    inf.close();

}


cxVolume::cxVolume(int volID)
{
    m_pVolume = NULL;

    m_pIndVolume = NULL;
/*
    m_startIndX = 0;
    m_stopIndX = 0;
    m_startIndY = 99;
    m_stopIndY = 99;
    m_IndYsize = 100;
    m_IndXsize = 100;
*/
    m_startIndX = 0;
    m_stopIndX = 99;
    m_startIndY = 0;
    m_stopIndY = 99;
    m_IndYsize = 100;
    m_IndXsize = 100;

    m_time_in = 0;
    m_time_out = 1;

    m_nVolumeType = VOLUME_TYPE_FLOAT;
    m_nTexVol = 0;
    m_nIndTexVol = 0;
    m_nTexBack = 0;
    m_nVolProgram = 0;
    m_fNormalSpacing = 1.0/64.0;     
    m_nSliceAxis = SLICE_X_AXIS;
    m_bDraw2DSliceBoundary = false;
    m_pVisStatus = new cxVisStatus;
    m_pVisStatus->m_nVolumeID = volID;
    
    m_bReload = false;
    
    m_nTexColorMap = 0;
    m_nTexTF = 0;
    m_bDrawColorMap = true;
    
    for ( int i = 0; i < 3; i++)
        m_nTexGrid[i] = 0;
    
    m_nVolumeID = volID;
    
    m_nImportance = 5;
    
    InitVolume();    
        
    for (int i = 0; i < 3; i++)
        m_pGrid[i] = NULL;
        
        
    m_pTime = NULL;
    
    if(utInit("/etc/udunits.dat") != 0){
        printf("Error! Can not init udunits\n");
    }
    m_netcdf = NULL;
}


cxVolume::~cxVolume()
{
    ClearVolume();
    if(m_netcdf)
	delete m_netcdf;
}


cx3DVector cxVolume::GetCeneter()
{
    return m_vCenter;
}


unsigned char Stretch_Linear(int x, int y, int desX, int desY, int srcX, int srcY, const unsigned char * Vx)
{
    float xx = x*srcX/((float)desX);
    float yy = y*srcY/((float)desY);
    
    float n = xx - ((int)xx);
    float b = yy - ((int)yy);
    
    int PAX = (int)xx;
    int PAY = (int)yy;
    int PBX = (PAX+1 > srcX-1)? PAX : PAX+1;
    int PBY = PAY;
    int PCX = PAX;
    int PCY = (PAY+1 > srcY-1)? PAY : PAY+1;
    int PDX = PBX;
    int PDY = PCY;
    
    int idA = PAX + PAY * srcX;
    int idB = PBX + PBY * srcX;
    int idC = PCX + PCY * srcX;
    int idD = PDX + PDY * srcX;
    
    float vx = n*b*Vx[idA] + n*(1-b)*Vx[idB] + (1-n)*b*Vx[idC] + (1-n)*(1-b)*Vx[idD];
    
    return (unsigned char)vx;
}

void cxVolume::GetSnapshot(unsigned char * output, int output_w, int output_h)
{
#ifdef WIN_SLICE
    int width = m_pVisView->m_nImagewidth;
    int height = m_pVisView->m_nImageheight;
    static unsigned char * buffer = m_pVisView->m_pImage;
#else
    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);
        
    int width = viewport[2]; 
    int height = viewport[3];
    long buffersize = width*height*3;
    static unsigned char * buffer = new unsigned char[buffersize];    
    glReadPixels(0, 0, width, height, GL_RGB, GL_UNSIGNED_BYTE, buffer); 
#endif    
    
    
    int colorsize = width*height;
    
    unsigned char *R = new unsigned char[colorsize];
    unsigned char *G = new unsigned char[colorsize];
    unsigned char *B = new unsigned char[colorsize];
    
    assert(output);
    assert(R);
    assert(G);
    assert(B);
    
    for ( int i = 0; i < colorsize; i++){
        R[i] = buffer[i*3+0];
        G[i] = buffer[i*3+1];
        B[i] = buffer[i*3+2];
    }
    
    for (int y = 0; y < output_h; y++)
    for (int x = 0; x < output_w; x++){        
        int id = x + y * output_w;
        y = output_h - y - 1;
        output[id*3 + 0] = Stretch_Linear(x, y, output_w, output_h, width, height, R);
        output[id*3 + 1] = Stretch_Linear(x, y, output_w, output_h, width, height, G);
        output[id*3 + 2] = Stretch_Linear(x, y, output_w, output_h, width, height, B);
    }
    
    delete [] R;
    delete [] G;
    delete [] B;
}

    
void cxVolume::SetSize(cx3DVector size)
{ 
    m_vSize = size;
    m_fMaxSize = m_vSize[0];
    
    if ( m_fMaxSize < m_vSize[1] )
        m_fMaxSize = m_vSize[1];
        
    if ( m_fMaxSize < m_vSize[2] )
        m_fMaxSize = m_vSize[2];
        
}

void cxVolume::SetSize(int x, int y, int z)
{
    SetSize(cx3DVector(x, y, z));
}


void cxVolume::SetCenter(cx3DVector center)
{ 
    m_vCenter = center;
}

void cxVolume::SetCenter(int x, int y, int z)
{
    m_vCenter = cx3DVector(x, y, z);
}

void cxVolume::ReDraw(bool bReDrawAll)
{
#ifdef WIN_SLICE
    for ( int i = 0; i < 3; i++) {
        if (m_pSliceView[i] != NULL)
            m_pSliceView[i]->redraw();
    }
#endif    

    if (bReDrawAll) {        
        if (m_pVisView != NULL) {            
            m_pVisView->redraw();
        }
    }
    
}

void cxVolume::ClearVolume()
{
    if (m_pVolume != NULL)
    {
        delete [] (float*) m_pVolume;                    
        m_pVolume = NULL;                    
    }

    if (m_pIndVolume != NULL)
    {
        delete [] (float*) m_pIndVolume;                    
        m_pIndVolume = NULL;                    
    }

}

void cxVolume::ClearVolTex()
{
    if (m_nTexVol != 0) {
        glDeleteTextures(1, (const GLuint*)&m_nTexVol);
        m_nTexVol = 0;
    }
   
    if (m_nIndTexVol != 0) {
        glDeleteTextures(1, (const GLuint*)&m_nIndTexVol);
        m_nIndTexVol = 0;
    }
}

void cxVolume::InitVolume()
{
    //read parameters from file
    cxParameters parameters;
    parameters.ParseFile("volumerender.cfg");
    m_sFilename = parameters.GetInputFile(m_nVolumeID); 
    m_nStartTime = parameters.m_nStartTime;
    m_nEndTime = parameters.m_nEndTime;
    m_nCurTime = m_nStartTime;  
    
    m_pVisStatus->ReadFromFile();
}


void cxVolume::Read()
{

    ClearVolume();
    ClearVolTex();
    
    ReadFile();

    CreateDataTex();

    ClearVolume();
    
    ReadGrid("/home/sukharev/dev/vol_rend_proj/volumerender/grid.dat");
    
    ReadTime("/home/sukharev/dev/vol_rend_proj/volumerender/time.dat");
}

void cxVolume::Read(const char* index)
{

    ClearVolume();
    ClearVolTex();
    
    ReadNetCDF(m_netcdf, index, m_time_in, m_time_out);

    CreateDataTex();
    CreateIndexDataTex();

    ClearVolume();
    
    ReadGrid("/home/sukharev/dev/vol_rend_proj/volumerender/grid.dat");
    
    ReadTime("/home/sukharev/dev/vol_rend_proj/volumerender/time.dat");
}


bool cxVolume::Forward()
{
    m_nCurTime++;
    
    if (m_nCurTime > m_nEndTime) {
        m_nCurTime = m_nStartTime;
        m_pVisView->m_bEnd = true;
        return false;
        
    }
    
    return true;
}

void cxVolume::ReadNetCDF(NetCDF* netcdf, const char* index, int time_in, int time_out)
{
    // read header info
    if(!netcdf && !m_netcdf)
	return;
    if(!netcdf && m_netcdf)
	netcdf = m_netcdf;
	
    try{

    strcpy(m_curnetcdf_var,index);
   
    int x, y, z, t;
    x = y = z = t = 1;
    string type;

    NetCFD_var* var_info = netcdf->get_varinfo(m_curnetcdf_var);

    if (strcmp(var_info->var_name,"mixfrac") == 0)
        m_nVariable = DATA_MIXFRAC;
       
    if (strcmp(var_info->var_name,"HO2") == 0)
        m_nVariable = DATA_HO2;
   
    if (strcmp(var_info->var_name,"OH") == 0)
        m_nVariable = DATA_OH;
       
    if (strcmp(var_info->var_name,"chi") == 0)
        m_nVariable = DATA_CHI;
   
    if (strcmp(var_info->var_name,"temp") == 0)
        m_nVariable = DATA_TEMP;
   
    if (strcmp(var_info->var_name,"salt") == 0)
        m_nVariable = DATA_SALT;
    if (strcmp(var_info->var_name,"wt") == 0)
        m_nVariable = DATA_WT;

    if (var_info->rh_ndims == 4)
    {
	t = var_info->dim[0]->length;
	z = var_info->dim[1]->length;
	y = var_info->dim[2]->length;
	x = var_info->dim[3]->length;
    }

    if ( var_info->rh_type == NC_FLOAT) {
        m_nVolumeType = VOLUME_TYPE_FLOAT;
    } else if (var_info->rh_type == NC_SHORT) {
        m_nVolumeType = VOLUME_TYPE_SHORT;       
    } else if (var_info->rh_type == NC_BYTE) {
        m_nVolumeType = VOLUME_TYPE_BYTE;       
    } else {
        //assert(0); // unknow data type
        m_nVolumeType = VOLUME_TYPE_FLOAT;
    }

    m_nVolumeSize = x * y * z;
   
    SetSize(x, y, z);
    SetCenter( x/2, y/2, z/2);


    // read data

    if ( m_nTexVol!= 0)  
       glDeleteTextures(1, (const GLuint*)&m_nTexVol);
    
    if ( m_nIndTexVol!= 0)
       glDeleteTextures(1, (const GLuint*)&m_nIndTexVol);

    m_pVolume = new float[m_nVolumeSize];
    m_pIndVolume = new float[m_nVolumeSize];
    if( m_pVolume == NULL || m_pIndVolume == NULL) {
        cerr << "Memory leak" << endl;
        return;
    }

    if (m_nVolumeType == VOLUME_TYPE_FLOAT) {

	netcdf->get_vardata(const_cast<char *>(m_curnetcdf_var), m_time_in, m_time_out, 0, 1, reinterpret_cast<char **>(&m_pVolume), true);
        float min, max;

#ifdef QUANTIZATION
        if (m_nVariable != DATA_MIXFRAC ) {
            
            if (m_nVariable == DATA_HO2) {
                min = 0;
                //max = 0.000343621;
                max = 0.000316;
            }            
            else if (m_nVariable == DATA_OH) {
                min = 0;
                max = 0.0207485;
            }            
            else if (m_nVariable == DATA_CHI) {
                //min = 0;
                //max = 12.2035;
                min = -2.0;
                //max = 0.75;
                max = 0.5;
            }
            else if (m_nVariable == DATA_TEMP) {
                min = 20.0f;
                max = 30.0f;            
            }
            else if (m_nVariable == DATA_SALT) {
                min = 30.0f;
                max = 37.0f;            
            }
	    else if (m_nVariable == DATA_WT) {
                min = -0.00001f;
                max = 0.00001f;            
            }
            else { 

#ifdef SUPERNOVA
                min = 0.0f;
                max = 204.728 * 1.5;
#else
                min = max = m_pVolume[0];
        
                for (int i = 1; i < m_nVolumeSize; i++) {
                    if ( min > m_pVolume[i] )
                        min = m_pVolume[i];
                    if ( max < m_pVolume[i])
                        max = m_pVolume[i];
                }
                
                cout << "min " << min << " max " << max << endl;
#endif                
                
            }
                
            m_fMin = min;
            m_fMax = max;    
            for (int i = 0; i < m_nVolumeSize; i++) {
                if ( m_nVariable == DATA_CHI) {
                    if (m_pVolume[i] > 0)
                        m_pVolume[i] = (log(m_pVolume[i] / 10400.0)/ log(10) - min) / (max - min);
                    
                    if (m_pVolume[i] < 0)
                        m_pVolume[i] = 0;
                    if (m_pVolume[i] > 1)
                        m_pVolume[i] = 1;
                }else {
                           
                    if(min < 0)
			min = 0;
		    if(max < 0)
			max = -max;
			
		    float value = (m_pVolume[i] - min) / (max - min);

#if defined(CLIMATE) 
                
                    if (m_pVolume[i] < -100)
                        m_pVolume[i] = 0;
                    else
                        m_pVolume[i] = (value < 0) ? 0.1 : value;
#else
                    m_pVolume[i] = value;
#endif                                    
                    
                }
            }

	    if (m_stopIndX == m_startIndX &&  m_startIndX == 0){
	    	m_stopIndX = m_vSize[0];
		m_startIndX = 0;
	    } 
	
	    if (m_stopIndY == m_startIndY &&  m_startIndY == 0){
	    	m_stopIndY = m_vSize[1];
		m_startIndY = 0;
	    } 
#if defined(CLIMATE)            


            // reverse the z direction  

            for (int z = 0; z < m_vSize[2] / 2; z++)
            for (int y = 0; y < m_vSize[1]; y++) 
            for (int x = 0; x < m_vSize[0]; x++) {
                int org_id = x + y * m_vSize[0] + z * m_vSize[0] * m_vSize[1];
                int new_id = x + y * m_vSize[0] + (m_vSize[2] - 1 - z) * m_vSize[0] * m_vSize[1];
                float temp = m_pVolume[new_id];
                m_pVolume[new_id] = m_pVolume[org_id];            
                m_pVolume[org_id] = temp;

		if (	(x <= (m_stopIndX *m_vSize[0] /100) && x >= (m_startIndX *m_vSize[0] /100)) && 
			(y <= (m_stopIndY *m_vSize[1] /100) && y >= (m_startIndY*m_vSize[1] /100)))
			m_pIndVolume[new_id] = m_pVolume[new_id];
		else 
			m_pIndVolume[new_id] = 0; //30

            }
            
#endif            
            
        }
        
#endif        
    } else if (m_nVolumeType == VOLUME_TYPE_SHORT) {
    
        unsigned short * pTempVolume = new unsigned short[m_nVolumeSize];
        assert(pTempVolume);
        netcdf->get_vardata(const_cast<char *>(m_curnetcdf_var), m_time_in, m_time_out, 0,1, reinterpret_cast<char **>(&pTempVolume), true);

        float max = pTempVolume[0];
        float min = pTempVolume[0];
        
        //find min and max
        for (int i = 0; i < m_nVolumeSize; i++) {
            if ( max < pTempVolume[i])
                max = pTempVolume[i];
            if ( min > pTempVolume[i])
                min = pTempVolume[i];
        }
        
        max *= 0.01;
        cout << "Max " << max << endl;
        cout << "Min " << min << endl;
        
        for (int i = 0; i < m_nVolumeSize; i++) 
            m_pVolume[i] = ((float) pTempVolume[i] - min) / (max - min);           
        
        //
        //for (int i = 0; i < m_nVolumeSize; i++) 
        //    m_pVolume[i] = ((float) pTempVolume[i] ) / 0xffff;            
        //
            
        delete [] pTempVolume;
    
    } else if (m_nVolumeType == VOLUME_TYPE_BYTE) {

        unsigned char * pTempVolume = new unsigned char[m_nVolumeSize];
        assert(pTempVolume);
        netcdf->get_vardata(const_cast<char *>(m_curnetcdf_var), m_time_in, m_time_out, 0,1,reinterpret_cast<char **>(&pTempVolume), true);

        for (int i = 0; i < m_nVolumeSize; i++) {
            m_pVolume[i] = ((float)pTempVolume[i]) / 0xff;
        }

        delete [] pTempVolume;
    }
    
#ifdef HISTOGRAM
    int wid = m_pHistogram->w();
    int hei = m_pHistogram->h();
    
    int * count = new int[wid];
    assert(count);
    
    memset(count, 0, sizeof(int) * wid);
    
    int max = 0;
    for (int i = 0; i < m_nVolumeSize; i++) {
        float value = m_pVolume[i];
        
        int id = int(value * float(wid - 1));
        if (id > wid - 1)
            id = wid - 1;
            
        count[id]++;
        
        if (count[id] > max)
            max = count[id];
            
    }
        
    int sum = 0;
    for ( int i = 0; i < wid; i++)
        sum += count[i];
        
    int avg = sum / wid;
    
    uchar * histogram = m_pHistogram->m_pImage;
    memset(histogram, 0, wid * hei * 3);
    
    for (int x = 0; x < wid; x++) {
        int max_id = int(float(count[x]) / float(avg) * float(hei)); 
        if (max_id > hei - 1)
            max_id = hei - 1;
            
        for (int y = hei - 1; y > hei -1 - max_id; y--) {
            int id = x + y * wid;
            histogram[id * 3 + 0] = 255;
            histogram[id * 3 + 1] = 255;
            histogram[id * 3 + 2] = 255;
        }
    }    
    delete count; 
#endif

   }
   catch(...)
   {
	m_nVolumeSize = 0;
   }
}

void cxVolume::ReadFile()
{
    char head_file[1024];
    char data_file[1024];
    char temp[1024];
    
    if (m_nStartTime == -1){
        sprintf(head_file, "%s.hdr", m_sFilename.c_str());
        sprintf(data_file, "%s.dat", m_sFilename.c_str());
    }
    else {
        cout << "Load timestep " << m_nCurTime << endl;
        
        ostringstream timestep;
        timestep << setw(4) << setfill('0') << m_nCurTime;
        
        sprintf(temp, "%s.hdr", m_sFilename.c_str());
        sprintf(head_file, temp, timestep.str().c_str(), timestep.str().c_str());
        
        sprintf(temp, "%s.dat", m_sFilename.c_str());
        sprintf(data_file, temp, timestep.str().c_str(), timestep.str().c_str());
        
    }
    
    if (m_sFilename.find("mixfrac") != string::npos)
        m_nVariable = DATA_MIXFRAC;
        
    if (m_sFilename.find("HO2") != string::npos)
        m_nVariable = DATA_HO2;
        
    if (m_sFilename.find("OH") != string::npos)
        m_nVariable = DATA_OH;
        
    if (m_sFilename.find("chi") != string::npos)
        m_nVariable = DATA_CHI;
        
    if (m_sFilename.find("temp") != string::npos)
        m_nVariable = DATA_TEMP;
        
    if (m_sFilename.find("salt") != string::npos)
        m_nVariable = DATA_SALT;        
    
    ReadHeader(head_file);       
    ReadData(data_file);    
}

void cxVolume::ReadHeader(char * filename)
{
    int x, y, z;
    string type;
    
#ifdef READ_HEADFILE    
    ifstream headfile(filename); 
    if (headfile == NULL) {
        cerr << "Can not open " << filename << endl;
        return;
    }          
    
    headfile >> x >> y >> z;
    headfile >> type;
    headfile.close();    
    
    if (type == "FLOAT" || type == "Float" || type == "float") {
        m_nVolumeType = VOLUME_TYPE_FLOAT;
    } else if (type == "SHORT" || type == "Short" || type == "short") {
        m_nVolumeType = VOLUME_TYPE_SHORT;        
    } else if (type == "BYTE" || type == "Byte" || type == "byte") {
        m_nVolumeType = VOLUME_TYPE_BYTE;        
    } else {
        //assert(0); // unknow data type
        m_nVolumeType = VOLUME_TYPE_FLOAT;
    }
#else
    x = 800;
    y = 686;
    z = 215;    
    m_nVolumeType = VOLUME_TYPE_FLOAT;
#endif
    
    m_nVolumeSize = x * y * z;
    
    SetSize(x, y, z);
    SetCenter( x/2, y/2, z/2);
}


void cxVolume::ReadData(char * filename)
{
    ifstream datafile(filename, ios_base::binary);
    
    if (datafile == NULL) {
        cerr << "Can not open " << filename << endl;
        return;
    }    

    if ( m_nTexVol!= 0)  
       glDeleteTextures(1, (const GLuint*)&m_nTexVol);

    if ( m_nIndTexVol!= 0)  
       glDeleteTextures(1, (const GLuint*)&m_nIndTexVol);
       
    m_pVolume = new float[m_nVolumeSize];
    if( m_pVolume == NULL) {
        cerr << "Memory leak" << endl;
        return;
    }

    if (m_nVolumeType == VOLUME_TYPE_FLOAT) {

        datafile.read(reinterpret_cast<char *>(m_pVolume), sizeof(float) * m_nVolumeSize);
               
        float min, max;

#ifdef QUANTIZATION
        if (m_nVariable != DATA_MIXFRAC ) {
            
            if (m_nVariable == DATA_HO2) {
                min = 0;
                //max = 0.000343621;
                max = 0.000316;
            }            
            else if (m_nVariable == DATA_OH) {
                min = 0;
                max = 0.0207485;
            }            
            else if (m_nVariable == DATA_CHI) {
                //min = 0;
                //max = 12.2035;
                min = -2.0;
                //max = 0.75;
                max = 0.5;
            }
            else if (m_nVariable == DATA_TEMP) {
                min = 20.0f;
                max = 30.0f;            
            }
            else if (m_nVariable == DATA_SALT) {
                min = 30.0f;
                max = 37.0f;            
            }
	    else if (m_nVariable == DATA_WT) {
                min = 30.0f;
                max = 37.0f;            
            }
            else { 

#ifdef SUPERNOVA
                min = 0.0f;
                max = 204.728 * 1.5;
#else
                min = max = m_pVolume[0];
        
                for (int i = 1; i < m_nVolumeSize; i++) {
                    if ( min > m_pVolume[i] )
                        min = m_pVolume[i];
                    if ( max < m_pVolume[i])
                        max = m_pVolume[i];
                }
                
                cout << "min " << min << " max " << max << endl;
#endif                
                
            }
                
            m_fMin = min;
            m_fMax = max;    
            for (int i = 0; i < m_nVolumeSize; i++) {
                if ( m_nVariable == DATA_CHI) {
                    if (m_pVolume[i] > 0)
                        m_pVolume[i] = (log(m_pVolume[i] / 10400.0)/ log(10) - min) / (max - min);
                    
                    if (m_pVolume[i] < 0)
                        m_pVolume[i] = 0;
                    if (m_pVolume[i] > 1)
                        m_pVolume[i] = 1;
                }else {
                           
                    float value = (m_pVolume[i] - min) / (max - min);

#if defined(CLIMATE) 
                
                    if (m_pVolume[i] < -100)
                        m_pVolume[i] = 0;
                    else
                        m_pVolume[i] = (value < 0) ? 0.1 : value;
#else
                    m_pVolume[i] = value;
#endif                                    
                    
                }
            }
            
#if defined(CLIMATE)            

            /* reverse the z direction */ 
            for (int z = 0; z < m_vSize[2] / 2; z++)
            for (int y = 0; y < m_vSize[1]; y++) 
            for (int x = 0; x < m_vSize[0]; x++) {
                int org_id = x + y * m_vSize[0] + z * m_vSize[0] * m_vSize[1];
                int new_id = x + y * m_vSize[0] + (m_vSize[2] - 1 - z) * m_vSize[0] * m_vSize[1];
                float temp = m_pVolume[new_id];
                m_pVolume[new_id] = m_pVolume[org_id];            
                m_pVolume[org_id] = temp;
            }
            
#endif            
            
        }
        
#endif        
    } else if (m_nVolumeType == VOLUME_TYPE_SHORT) {
    
        unsigned short * pTempVolume = new unsigned short[m_nVolumeSize];
        assert(pTempVolume);
        datafile.read(reinterpret_cast<char *>(pTempVolume), sizeof(unsigned short) * m_nVolumeSize);

        float max = pTempVolume[0];
        float min = pTempVolume[0];
        
        //find min and max
        for (int i = 0; i < m_nVolumeSize; i++) {
            if ( max < pTempVolume[i])
                max = pTempVolume[i];
            if ( min > pTempVolume[i])
                min = pTempVolume[i];
        }
        
        max *= 0.01;
        cout << "Max " << max << endl;
        cout << "Min " << min << endl;
        
        for (int i = 0; i < m_nVolumeSize; i++) 
            m_pVolume[i] = ((float) pTempVolume[i] - min) / (max - min);           
        
        /*
        for (int i = 0; i < m_nVolumeSize; i++) 
            m_pVolume[i] = ((float) pTempVolume[i] ) / 0xffff;            
        */
            
        delete [] pTempVolume;
    
    } else if (m_nVolumeType == VOLUME_TYPE_BYTE) {

        unsigned char * pTempVolume = new unsigned char[m_nVolumeSize];
        assert(pTempVolume);
        datafile.read(reinterpret_cast<char *>(pTempVolume), sizeof(unsigned char) * m_nVolumeSize);

        for (int i = 0; i < m_nVolumeSize; i++) {
            m_pVolume[i] = ((float)pTempVolume[i]) / 0xff;
        }

        delete [] pTempVolume;
    }
    
#ifdef HISTOGRAM
    int wid = m_pHistogram->w();
    int hei = m_pHistogram->h();
    
    int * count = new int[wid];
    assert(count);
    
    memset(count, 0, sizeof(int) * wid);
    
    int max = 0;
    for (int i = 0; i < m_nVolumeSize; i++) {
        float value = m_pVolume[i];
        
        int id = int(value * float(wid - 1));
        if (id > wid - 1)
            id = wid - 1;
            
        count[id]++;
        
        if (count[id] > max)
            max = count[id];
            
    }
        
    int sum = 0;
    for ( int i = 0; i < wid; i++)
        sum += count[i];
        
    int avg = sum / wid;
    
    uchar * histogram = m_pHistogram->m_pImage;
    memset(histogram, 0, wid * hei * 3);
    
    for (int x = 0; x < wid; x++) {
        int max_id = int(float(count[x]) / float(avg) * float(hei)); 
        if (max_id > hei - 1)
            max_id = hei - 1;
            
        for (int y = hei - 1; y > hei -1 - max_id; y--) {
            int id = x + y * wid;
            histogram[id * 3 + 0] = 255;
            histogram[id * 3 + 1] = 255;
            histogram[id * 3 + 2] = 255;
        }
    }    
    delete count; 
#endif
        
    datafile.close();

}


void cxVolume::ReadGrid(char * filename)
{
    /* read the grid file */
    ifstream inf(filename);
    assert(inf);
        
    /* allocate memory */        
    for (int i = 0; i < 3; i++) {
        
        int size = (int)m_vSize[i];
        
        if (m_pGrid[i] != NULL)
            delete [] m_pGrid[i];
        
        m_pGrid[i] = new float[size];
        assert(m_pGrid[i]);
        
        inf.read(reinterpret_cast<char *>(m_pGrid[i]), sizeof(float) * size);
    
        /* normalize */
        float min, max;
        
        min = m_pGrid[i][0];
        max = m_pGrid[i][size - 1];
        
        for (int j = 0; j < size; j++) {
            m_pGrid[i][j] = (m_pGrid[i][j] - min) / (max - min);
        }
    }
    
    inf.close();    
}


void cxVolume::ReadTime(char *filename)
{
    int totaltime = m_nEndTime - m_nStartTime + 1;
    
    if (m_pTime == NULL) {
    
        m_pTime = new float[totaltime];
        assert(m_pTime);
    }
    
    /* read the time file */
    ifstream inf(filename);
    assert(inf);
    
    inf.read(reinterpret_cast<char *>(m_pTime), sizeof(float) * totaltime);
    
    inf.close();
}


void cxVolume::CreateDataTex()
{
    if(m_nTexVol==0)
    {
        glGenTextures(1, (GLuint*)&m_nTexVol);
        glActiveTexture(GL_TEXTURE0);
        glEnable(GL_TEXTURE_3D);
        glBindTexture(GL_TEXTURE_3D,m_nTexVol);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
        
        if (m_pVolume == NULL) {
            cerr << "The Volume is empty " << endl;
            return;
        }
        glTexImage3D(GL_TEXTURE_3D, 0, GL_LUMINANCE16, (int)m_vSize[0],
                    (int)m_vSize[1], (int)m_vSize[2], 0, GL_LUMINANCE, GL_FLOAT,
                    m_pVolume);
                  
        glDisable(GL_TEXTURE_3D);
    }else{
    
        glActiveTexture( GL_TEXTURE0);
        glEnable(GL_TEXTURE_3D);
        glBindTexture(GL_TEXTURE_3D, m_nTexVol);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
        glDisable(GL_TEXTURE_3D);
    }
}

void cxVolume::CreateIndexDataTex()
{
    if(m_nIndTexVol==0)
    {
        glGenTextures(1, (GLuint*)&m_nIndTexVol);
        glActiveTexture(GL_TEXTURE6);
        glEnable(GL_TEXTURE_3D);
        glBindTexture(GL_TEXTURE_3D,m_nIndTexVol);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
        
        if (m_pVolume == NULL) {
            cerr << "The Volume is empty " << endl;
            return;
        }
        glTexImage3D(GL_TEXTURE_3D, 0, GL_LUMINANCE16, (int)m_vSize[0],
                    (int)m_vSize[1], (int)m_vSize[2], 0, GL_LUMINANCE, GL_FLOAT,
                    m_pIndVolume);
                  
        glDisable(GL_TEXTURE_3D);
    }else{
    
        glActiveTexture( GL_TEXTURE6);
        glEnable(GL_TEXTURE_3D);
        glBindTexture(GL_TEXTURE_3D, m_nIndTexVol);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
        glDisable(GL_TEXTURE_3D);
	
    }
}
void cxVolume::GetEyePos()
{
    // calcuate the eye pos,
    GLdouble model[16];
    glGetDoublev(GL_MODELVIEW_MATRIX, model);
    
    // convert to the tranditional format
    double matrix[16];
    for (int i=0; i<4; i++)
        for (int j=0; j<4; j++)
            matrix[j+i*4] = model[i+j*4];
    
    inverse_mat(matrix, model);
    
    double eye[] = {0, 0, 0};
    double eye_rev[3];
    MAT_TIME_VEC(model, eye, eye_rev);     
    
    //translate to the texture coordinator
    m_vEye = cx3DVector(eye_rev[0] * m_fMaxSize / m_vSize[0] + 0.5, 
                        eye_rev[1] * m_fMaxSize / m_vSize[1] + 0.5, 
                        eye_rev[2] * m_fMaxSize / m_vSize[2] + 0.5); 

//     m_vEye = cx3DVector((eye_rev[0] + 0.5 * m_vSize[0] / m_fMaxSize) / (m_vSize[0] / m_fMaxSize), 
//                         (eye_rev[1] + 0.5 * m_vSize[1] / m_fMaxSize) / (m_vSize[1] / m_fMaxSize),
//                         (eye_rev[2] + 0.5 * m_vSize[2] / m_fMaxSize) / (m_vSize[2] / m_fMaxSize)); 

#ifdef ORTHO
    double eyedir[] = {0,0,1};
    double eyedir_rev[3];
    VEC_TIME_MAT(model, eyedir, eyedir_rev);
    m_vEyeDir = cx3DVector(eyedir_rev);    
    
    m_vEyeDir = m_vEye - cx3DVector(0.5, 0.5, 0.5);
    
    m_vEyeDir.normalize();
    
    
#endif
}


void cxVolume::Draw(int nDrawMode, int nSliceAxis)
{
    if (m_nTexVol == 0) {
    //    Read();
	return;
    }

    if(m_nIndTexVol == 0){
	return;
    }
        
    if (m_nVolProgram == 0 || m_bReload)
        InitProgram();
        
    if (nDrawMode == DRAW_3D_VOLUME)
        Draw3DVolume();
    else if(nDrawMode == DRAW_2D_SLICE){
        Draw2DSlice(nSliceAxis);
    }   
    m_pVisStatus->WriteToFile();
}


void cxVolume::Draw3DVolume()
{

#if defined(CLIMATE)    
    glScalef(0.44, 1.0, 1.0);
#endif

    GetEyePos();    
    
    
    
    glPushMatrix();

    float scale = 1.0 / m_fMaxSize;

    glScalef(scale, scale, scale);      
    glTranslatef( -m_vCenter[0], -m_vCenter[1], -m_vCenter[2]);
        
    if (m_pVisStatus->m_bDrawVolume)
        DrawVolume();
        
    if (m_pVisStatus->m_bDrawAxes)
       DrawAxes();
    
    if (m_pVisStatus->m_bDrawFrame)
       DrawFrame();
       
    //DrawGrid();
       
       

#ifdef DRAWIMPORTANCE        
    DrawImportance();            
#endif
    
    if (m_bDraw2DSliceBoundary)
        Draw2DSliceBoundary();
        
    if (m_bDrawColorMap)
        DrawColorMap();
        

        
    glPopMatrix();
}

void cxVolume::DrawImportance()
{
    char filename[1024];
    
    if (m_nVariable == DATA_TEMP) {
        
        sprintf (filename, "/home/hfyu/work/climate/importance/temp-importance/importance_%04d.txt", m_nCurTime);
    
    } else if (m_nVariable == DATA_SALT) {
    
        sprintf (filename, "/home/hfyu/work/climate/importance/salt-importance/importance_%04d.txt", m_nCurTime);
    
    }
    
    ifstream inf;
    
    inf.open(filename);
    
    assert(inf);
    
    int grid_x = 12;
    int grid_y = 6;
    
    float size_x = m_vSize[0] / grid_x;
    float size_y = m_vSize[1] / grid_y;
    
    int grid_id;
    float importance;
    int x, y;    
    float low_x, low_y, top_x, top_y;
    
    glDisable(GL_LIGHTING);
    glLineWidth(2.0);
    glColor3f(1, 0, 0);    
    
    for (int i = 0; i < m_nImportance; i++) 
    {
        
        inf >> grid_id >> importance;        
        
        
        y = grid_id / grid_x;
        
        x = grid_id - grid_x * y;
        
        low_x = x * size_x;
        
        low_y = y * size_y;
        
        top_x = low_x + size_x;
        
        top_y = low_y + size_y;
    
    
        glBegin(GL_LINE_LOOP);
            glVertex3f(low_x, low_y, m_vSize[2] + 1);
            glVertex3f(top_x, low_y, m_vSize[2] + 1);
            glVertex3f(top_x, top_y, m_vSize[2] + 1);
            glVertex3f(low_x, top_y, m_vSize[2] + 1);
            glVertex3f(low_x, low_y, m_vSize[2] + 1);
        glEnd();
    
    }
    
}


void cxVolume::DrawColorMap()
{
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();    
        
    gl_font(FL_HELVETICA_BOLD, 12);
    gl_color(FL_WHITE);
    
    float x, y, delta;
    x = 0.3;
    //y = -0.9 + m_nVolumeID * 0.15;
    y = -0.9 + m_nVolumeID * 0.22;
    delta = 0.08;
    
    switch(m_nVariable) {
        case DATA_MIXFRAC : gl_draw("MIXFRAC", x, y + delta);
                            break;
        case DATA_HO2     : gl_draw("HO2", x, y + delta);
                            break;                            
        case DATA_OH      : gl_draw("OH", x, y + delta);
                            break;                            
        case DATA_CHI     : gl_draw("CHI", x, y + delta);
                            break;
        case DATA_TEMP    : gl_draw("TEMP (degC)", x, y + delta);
                            break;                         
        case DATA_SALT    : gl_draw("SALT (psu)", x, y + delta);
                            break;  
	case DATA_WT    : gl_draw("WT (psu)", x, y + delta);
                            break;                                                    
    }

    char buf[1024];
    
    if(m_fMin < 1.0)
    	sprintf(buf, "%.8f", m_fMin);    
    else
	sprintf(buf, "%.2f", m_fMin);
    gl_draw(buf, x, y + delta - 0.15);
    
    if(m_fMax < 1.0)
    	sprintf(buf, "%.8f", m_fMax);    
    else
	sprintf(buf, "%.2f", m_fMax);
    gl_draw(buf, x + 0.52f, y + delta - 0.15f);
    
    
    /* convert the NetCDF time coordinates to a calendar date */
	
    utUnit unit;
    int year=0, month, day, hour, minute;
    float second;

    if (utScan("days since 0001-01-01 00:00:00", &unit) != 0) {
        printf("Error! Can not convert units\n");        
    }
    
    int cur = m_nCurTime - m_nStartTime;
    
    utCalendar(m_pTime[cur], &unit, &year, &month, &day, &hour, &minute, &second);
    
    //sprintf(buf, "TIME : %04d ( %02d mo | %04d yr )", m_nCurTime, m_nCurTime%12 + 1, m_nCurTime / 12 + 1);
    sprintf(buf, " timestep : %04d   mm/dd/yy : %02d-%02d-%04d", cur, month, day, year);
   
    gl_draw(buf, -1.0f, -0.95f);

    glTranslatef(x, y, 0);    
#ifdef SHOWOPACITY
    glScalef(0.6, 0.15, 1);
#else
    glScalef(0.6, 0.06, 1);
#endif

    CreateColorMapTex();
    
    glActiveTexture(GL_TEXTURE3);
    glEnable(GL_TEXTURE_2D);

    glBegin(GL_QUADS);
        glMultiTexCoord2f(GL_TEXTURE3, 0, 0);
        glVertex2f(0,0);
        
        glMultiTexCoord2f(GL_TEXTURE3, 1, 0);
        glVertex2f(1,0);         
        
        glMultiTexCoord2f(GL_TEXTURE3, 1, 1);
        glVertex2f(1,1);
        
        glMultiTexCoord2f(GL_TEXTURE3, 0, 1);
        glVertex2f(0,1);
    glEnd();
    
    glDisable(GL_TEXTURE_2D);    
    
    glPopMatrix();
    glPopMatrix();
}


void cxVolume::DrawGrid()
{
    int sizex = (int) m_vSize[0];
    int sizey = (int) m_vSize[1];
    int sizez = (int) m_vSize[2];
    
//     glPushMatrix();
//     
//     glDisable(GL_LIGHTING);
//     glLineWidth(1.0);
//     glColor3f(1.0f,1.0f,1.0f);
//     
//     for (int i = 0; i < sizex; i++){        
//         glBegin(GL_LINES);
//             glVertex3f(m_pGridX[i], m_pGridY[0], m_pGridZ[0]);
//             glVertex3f(m_pGridX[i], m_pGridY[sizey-1], m_pGridZ[0]);
//         glEnd();
//     }
//     
//     for (int i = 0; i < sizey; i++){        
//         glBegin(GL_LINES);
//             glVertex3f(m_pGridX[0], m_pGridY[i], m_pGridZ[0]);
//             glVertex3f(m_pGridX[sizex -1], m_pGridY[i], m_pGridZ[0]);
//         glEnd();
//     }
//     
//     for (int i = 0; i < sizez; i++){        
//         glBegin(GL_LINES);
//             glVertex3f(m_pGridX[0], m_pGridY[0], m_pGridZ[i]);
//             glVertex3f(m_pGridX[sizex -1], m_pGridY[0], m_pGridZ[i]);
//         glEnd();
//     }
//     
//     
    glPopMatrix();
}


void cxVolume::DrawFrame()
{
    float el = -1;
    float ew = -1;
    float eh = -1;
    float sl = m_vSize[0] + 1;
    float sw = m_vSize[1] + 1;
    float sh = m_vSize[2] + 1;
    
    glPushMatrix();
    
    glDisable(GL_LIGHTING);
    glLineWidth(1.0);
    
    if (m_pVisView->m_bBlack)
        glColor3f(1.0f,1.0f,1.0f);
    else
        glColor3f(0.0f,0.0f,0.0f);
    
    glBegin(GL_LINE_LOOP);
        glVertex3f(sl,sw,eh);
        glVertex3f(el,sw,eh);
        glVertex3f(el,ew,eh);
        glVertex3f(sl,ew,eh);
        glVertex3f(sl,sw,eh);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glVertex3f(sl,sw,eh);
        glVertex3f(sl,sw,sh);
        glVertex3f(sl,ew,sh);
        glVertex3f(sl,ew,eh);
    glEnd();

    glBegin(GL_LINE_STRIP);
        glVertex3f(el,sw,eh);
        glVertex3f(el,sw,sh);
        glVertex3f(el,ew,sh);
        glVertex3f(el,ew,eh);
    glEnd();
    
    glBegin(GL_LINES);
        glVertex3f(sl,ew,sh);
        glVertex3f(el,ew,sh);
    glEnd();
    
    glBegin(GL_LINES);
        glVertex3f(sl,sw,sh);
        glVertex3f(el,sw,sh);
    glEnd();

    glLineWidth(1.0);
    glColor3f(1.0f,0.0f,0.0f);
    glBegin(GL_LINES);

        glVertex3f(el,ew,eh);
        glVertex3f(sl,ew,eh);
    glEnd();

    glColor3f(0.0f,1.0f,0.0f);
    glBegin(GL_LINES);
        glVertex3f(el,ew,eh);
        glVertex3f(el,sw,eh);
    glEnd();

    glColor3f(0.0f,0.0f,1.0f);
    glBegin(GL_LINES);
        glVertex3f(el,ew,eh);
        glVertex3f(el,ew,sh);
    glEnd();

    glPopMatrix();
}


void cxVolume::DrawAxes()
{

    float pf = 10.0;
    // arrays for lighting
    GLfloat light_position0[ ] = {1.0f * pf, 1.0f * pf, 1.0f * pf, 0.0};
    GLfloat light_specular0[ ] =  {1.0, 1.0, 1.0, 1.0};
    GLfloat light_ambient0[ ] =  {1.0, 1.0, 1.0, 0.5};
    GLfloat light_diffuse0[ ] =  {1.0, 1.0, 1.0, 1.0};

    // For Lighting
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse0 );
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular0 );
    glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient0 );
    glLightfv(GL_LIGHT0, GL_POSITION, light_position0 );
    glEnable( GL_LIGHT0 );

    float x = m_vSize[0];
    float y = m_vSize[1];
    float z = m_vSize[2];

    float zoom = x / 5.0;
    
    glPushMatrix();
       
    glTranslatef(m_vCenter[0], m_vCenter[1], m_vCenter[2]);
      
    glDisable(GL_LIGHTING);

    glLineWidth(1.0);

    //RED - X
    glBegin(GL_LINES);
        glColor3f(1.0,0.0,0.0);
        glVertex3f(0, 0, 0);
        glVertex3f(x,0,0);
    glEnd();

    //GREEN - Y
    glBegin(GL_LINES);
        glColor3f(0.0,1.0,0.0);
        glVertex3f(0, 0, 0);
        glVertex3f(0,y,0);
    glEnd();

    //BLUE - Z
    glBegin(GL_LINES);
        glColor3f(0.0,0.0,1.0);
        glVertex3f(0, 0, 0);
        glVertex3f(0,0,z);
    glEnd();    


    glEnable(GL_LIGHTING);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    GLfloat light0_ambient[] =  {1.0f, 1.0f, 1.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
    glPushMatrix();
        GLfloat mat_ambient0[] = { 0.5, 0.0, 0.0, 1.0 };
        GLfloat mat_diffuse0[] = { 0.5, 0.0, 0.0, 1.0 };        
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient0);
        glMaterialfv(GL_FRONT, GL_DIFFUSE,mat_diffuse0);
        glTranslatef(x,0,0);
        glRotatef(90,0,1,0);
        glScalef(zoom, zoom, zoom);         
        //glutSolidCone(0.1, 0.3,8,8);
    glPopMatrix();
    
    glPushMatrix();
        GLfloat mat_ambient1[] = { 0.0, 0.5, 0.0, 1.0 };
        GLfloat mat_diffuse1[] = { 0.0, 0.5, 0.0, 1.0 };
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient1);
        glMaterialfv(GL_FRONT, GL_DIFFUSE,mat_diffuse1);
        glTranslatef(0,y,0);
        glRotatef(90,-1,0,0);
        glScalef(zoom, zoom, zoom);              
        //glutSolidCone(0.1, 0.3,8,8);
    glPopMatrix();

    glPushMatrix();
        GLfloat mat_ambient2[] = { 0.0, 0.0, 0.5, 1.0 };
        GLfloat mat_diffuse2[] = { 0.0, 0.0, 0.5, 1.0 };
        glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient2);
        glMaterialfv(GL_FRONT, GL_DIFFUSE,mat_diffuse2);
        glTranslatef(0,0,z);
        glScalef(zoom, zoom, zoom);               
        //glutSolidCone(0.1, 0.3,8,8);
    glPopMatrix();  
    
    glDisable(GL_LIGHTING);
    
    glPopMatrix();
}

void cxVolume::TurnOffTextureAndPrograms()
{
    for(int i=0;i<8;i++)
    {
        glActiveTexture( GL_TEXTURE0+i);
        glDisable(GL_TEXTURE_1D);
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_TEXTURE_3D);
        glDisable(GL_TEXTURE_RECTANGLE_NV);
    }
      
    // turn off fragment program
    glDisable(GL_FRAGMENT_PROGRAM_ARB);

    // turn off GL Shading language
    glUseProgram(0); 
}


void cxVolume::InitProgram()
{
    GLchar *VertexShaderSource, *FragmentShaderSource;
    readShaderSource("myVOL", &VertexShaderSource, &FragmentShaderSource);
    int success = installShaders(VertexShaderSource, FragmentShaderSource, (GLuint*)&(m_nVolProgram));        
    if ( !success)
    {
        fprintf(stderr, "Error: Can not install shaders.\n");   
    }
    free(VertexShaderSource);
    free(FragmentShaderSource);
    
    m_bReload = false;
}

void cxVolume::DrawCube()
{
    float minx = m_pVisStatus->m_vRangeMin[0];
    float miny = m_pVisStatus->m_vRangeMin[1];
    float minz = m_pVisStatus->m_vRangeMin[2];

    float maxx = m_pVisStatus->m_vRangeMax[0];
    float maxy = m_pVisStatus->m_vRangeMax[1];
    float maxz = m_pVisStatus->m_vRangeMax[2]; 
    
    float c[8][3] = {{minx,miny,minz},{maxx,miny,minz},{minx,maxy,minz},{maxx,maxy,minz},
                     {minx,miny,maxz},{maxx,miny,maxz},{minx,maxy,maxz},{maxx,maxy,maxz}};

    minx = minx * m_vSize[0];
    miny = miny * m_vSize[1];
    minz = minz * m_vSize[2];

    maxx = maxx * m_vSize[0];
    maxy = maxy * m_vSize[1];
    maxz = maxz * m_vSize[2];

    float v[8][3] = {{minx,miny,minz},{maxx,miny,minz},{minx,maxy,minz},{maxx,maxy,minz},
                     {minx,miny,maxz},{maxx,miny,maxz},{minx,maxy,maxz},{maxx,maxy,maxz}};

    
    glBegin(GL_QUADS);
        glColor3fv(c[0]); glVertex3fv(v[0]);
        glColor3fv(c[1]); glVertex3fv(v[1]);
        glColor3fv(c[3]); glVertex3fv(v[3]);
        glColor3fv(c[2]); glVertex3fv(v[2]);
        
        glColor3fv(c[1]); glVertex3fv(v[1]);
        glColor3fv(c[5]); glVertex3fv(v[5]);
        glColor3fv(c[7]); glVertex3fv(v[7]);
        glColor3fv(c[3]); glVertex3fv(v[3]);
        
        glColor3fv(c[4]); glVertex3fv(v[4]);
        glColor3fv(c[6]); glVertex3fv(v[6]);
        glColor3fv(c[7]); glVertex3fv(v[7]);
        glColor3fv(c[5]); glVertex3fv(v[5]);
        
        glColor3fv(c[0]); glVertex3fv(v[0]);
        glColor3fv(c[2]); glVertex3fv(v[2]);
        glColor3fv(c[6]); glVertex3fv(v[6]);
        glColor3fv(c[4]); glVertex3fv(v[4]);
        
        glColor3fv(c[0]); glVertex3fv(v[0]);
        glColor3fv(c[4]); glVertex3fv(v[4]);
        glColor3fv(c[5]); glVertex3fv(v[5]);
        glColor3fv(c[1]); glVertex3fv(v[1]);
        
        glColor3fv(c[2]); glVertex3fv(v[2]);
        glColor3fv(c[3]); glVertex3fv(v[3]);
        glColor3fv(c[7]); glVertex3fv(v[7]);
        glColor3fv(c[6]); glVertex3fv(v[6]);
    glEnd();
}

void cxVolume::CreateRayDirTex()
{    
    if (m_nTexBack == 0)
        glGenTextures(1, (GLuint*)&m_nTexBack);
        
    int width = m_pVisView->w();
    int height = m_pVisView->h();
    
 
    
    //Back face    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    DrawCube();
    glActiveTexture( GL_TEXTURE1 );    
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, m_nTexBack);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);    
    glCopyTexImage2D(GL_TEXTURE_2D, 0, GL_RGB , 0, 0, width, height, 0);    
    
//     int precision;    
//     glGetTexLevelParameteriv(GL_TEXTURE_2D, 0, GL_TEXTURE_RED_SIZE, &precision);    
//     cout << "precision " << precision << endl;
    
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_CULL_FACE);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void cxVolume::CreateTfTex()
{
    if (m_nTexTF == 0)
        glGenTextures(1, (GLuint*)&m_nTexTF);
        
        
    glActiveTextureARB( GL_TEXTURE2_ARB );
    glEnable(GL_TEXTURE_1D);
    glBindTexture(GL_TEXTURE_1D, m_nTexTF);
    glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
    
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);    
    
    static float * spacingAdjustedTF = new float[TF_SIZE*4];
    
    for(int i = 0;i < TF_SIZE; i++)
    {
        float alpha = m_pVisStatus->m_Colors[i].a();
        
        if (m_pVisView->m_bOperating)
            alpha = 1 - pow((1-alpha), 0.01f / m_fNormalSpacing );
        else
            alpha = 1 - pow((1-alpha), m_pVisStatus->m_fSampleSpacing / m_fNormalSpacing );

        spacingAdjustedTF[i*4+0] = m_pVisStatus->m_Colors[i].r() * alpha;
        spacingAdjustedTF[i*4+1] = m_pVisStatus->m_Colors[i].g() * alpha;
        spacingAdjustedTF[i*4+2] = m_pVisStatus->m_Colors[i].b() * alpha;
        spacingAdjustedTF[i*4+3] = alpha;
    }
    
    glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA_FLOAT16_ATI, TF_SIZE, 0, GL_RGBA, GL_FLOAT, spacingAdjustedTF);
            
    glDisable(GL_TEXTURE_1D);

}

void cxVolume::CreateColorMapTex()
{
    if (m_nTexColorMap == 0)
        glGenTextures(1, (GLuint*)&m_nTexColorMap);
        
        
    glActiveTexture(GL_TEXTURE3);
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, m_nTexColorMap);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);        
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); 
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);       
    
    int factor = 4;
    
    int width = TF_SIZE / factor;

    int height = width * 2;
    
    static float * TF = new float[width * height * 3];
    
    memset(TF, 0, sizeof(float) * width * height * 3);
    
    /* color */
    for (int x = 0; x < width; x++) {
        float r = m_pVisStatus->m_Colors[x * factor].r();
        float g = m_pVisStatus->m_Colors[x * factor].g();
        float b = m_pVisStatus->m_Colors[x * factor].b();
        float a = m_pVisStatus->m_Colors[x * factor].a();
        
#ifdef SHOWOPACITY
        #define OPACITY_HIGH (2.0/3.0)
#else
        #define OPACITY_HIGH 0
#endif

        for (int y = height * OPACITY_HIGH; y < height - 1; y++) {
            int id = x + y * width;
            
            TF[id * 3 + 0] = r;
            TF[id * 3 + 1] = g;
            TF[id * 3 + 2] = b;
        }
        
        
        for (int y = 0; y < height * OPACITY_HIGH * a; y++) {
            int id = x + y * width;
            
            TF[id * 3 + 0] = 1;
            TF[id * 3 + 1] = 1;
            TF[id * 3 + 2] = 1;
        
        }
    }
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA_FLOAT16_ATI, width, height, 0, GL_RGB, GL_FLOAT, TF);
            
    glDisable(GL_TEXTURE_2D);
}


void cxVolume::CreateGridTex()
{
    static float *GridMap = new float[GRID_SAMPLE];
    
    /* create texture for each axis */    
    for (int axis = 0; axis < 3; axis++) {        
        
        int size = m_vSize[axis];
    
        /* fill the look up table */
        for (int i = 0; i < size - 1; i++) {
        
            int start = m_pGrid[axis][i] * GRID_SAMPLE;            
            int end = m_pGrid[axis][i+1] * GRID_SAMPLE;
        
            float start_v = (float) i / size;            
            float end_v = (float) (i+1) / size;
        
            for (int j = start; j <= end; j++) {
        
                float factor = ((float) (j - start)) / (end - start);
                float value = start_v * (1-factor) + end_v * (factor);
                
                GridMap[j] = value;
                
            }
        }
        
        /* create the texture */
        if (m_nTexGrid[axis] == 0)
            glGenTextures(1, (GLuint*)&(m_nTexGrid[axis]));
        
        
        glActiveTextureARB( GL_TEXTURE3+axis );
        glEnable(GL_TEXTURE_1D);
        glBindTexture(GL_TEXTURE_1D, m_nTexGrid[axis]);
        
        glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
        glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);    
       
        glTexImage1D(GL_TEXTURE_1D, 0, GL_LUMINANCE16, GRID_SAMPLE, 0, GL_LUMINANCE, GL_FLOAT, GridMap);
            
        glDisable(GL_TEXTURE_1D);        
    }
}


void cxVolume::DrawVolume()
{
    //CreateRayDirTex();

    CreateTfTex();

    CreateDataTex();
    CreateIndexDataTex();

    CreateGridTex();

    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA );
    

    glUseProgram(m_nVolProgram);    
    glUniform1i(glGetUniformLocation(m_nVolProgram, "volumeTex"), 0);    
    //glUniform1i(glGetUniformLocation(m_nVolProgram, "backTex"), 1);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "tfTex"), 2);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexX"), 3);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexY"), 4);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexZ"), 5);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "volumeIndTex"),6);

    //glUniform1f(glGetUniformLocation(m_nVolProgram, "screenWidth"), width);
    //glUniform1f(glGetUniformLocation(m_nVolProgram, "screenHeight"), height);
    
    if (m_pVisView->m_bOperating)
        glUniform1f(glGetUniformLocation(m_nVolProgram, "sampleSpacing"),  0.01);
    else
        glUniform1f(glGetUniformLocation(m_nVolProgram, "sampleSpacing"),  m_pVisStatus->m_fSampleSpacing);
        
    glUniform4f(glGetUniformLocation(m_nVolProgram, "lightPar"), 
                m_pVisStatus->m_fLightPar[0],  m_pVisStatus->m_fLightPar[1], 
                m_pVisStatus->m_fLightPar[2],  m_pVisStatus->m_fLightPar[3]);
    glUniform3f(glGetUniformLocation(m_nVolProgram, "eyePos"), m_vEye[0], m_vEye[1], m_vEye[2]);
        
    float centralDifferenceSpacing[3];    
    for(int i = 0; i < 3; i++)
        centralDifferenceSpacing[i] = 1.0 / m_vSize[i];

    glUniform3f(glGetUniformLocation(m_nVolProgram, "centralDifferenceSpacing"), 
                centralDifferenceSpacing[0],centralDifferenceSpacing[1],centralDifferenceSpacing[2]);    
    
    glUniform1i(glGetUniformLocation(m_nVolProgram, "drawSlice"), 0);
    
#ifdef ORTHO    
    glUniform3f(glGetUniformLocation(m_nVolProgram, "eyeDir"), m_vEyeDir[0], m_vEyeDir[1], m_vEyeDir[2]);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "bOrtho"), 1);
#else
    glUniform3f(glGetUniformLocation(m_nVolProgram, "eyeDir"), 0,0,0);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "bOrtho"), 0);
#endif    

    glUniform1f(glGetUniformLocation(m_nVolProgram, "shiftDis"),  m_pVisStatus->m_fShiftDis);

    float minx = m_pVisStatus->m_vRangeMin[0];
    float miny = m_pVisStatus->m_vRangeMin[1];
    float minz = m_pVisStatus->m_vRangeMin[2];

    float maxx = m_pVisStatus->m_vRangeMax[0];
    float maxy = m_pVisStatus->m_vRangeMax[1];
    float maxz = m_pVisStatus->m_vRangeMax[2]; 
    
    float t[8][3] = {{minx,miny,minz},{maxx,miny,minz},{minx,maxy,minz},{maxx,maxy,minz},
                     {minx,miny,maxz},{maxx,miny,maxz},{minx,maxy,maxz},{maxx,maxy,maxz}};

    minx = minx * m_vSize[0];
    miny = miny * m_vSize[1];
    minz = minz * m_vSize[2];

    maxx = maxx * m_vSize[0];    
    maxy = maxy * m_vSize[1];
    maxz = maxz * m_vSize[2];

    float v[8][3] = {{minx,miny,minz},{maxx,miny,minz},{minx,maxy,minz},{maxx,maxy,minz},
                     {minx,miny,maxz},{maxx,miny,maxz},{minx,maxy,maxz},{maxx,maxy,maxz}};
    
           
    //Front face
    glEnable(GL_CULL_FACE);
    glCullFace(GL_FRONT);
    
    glBegin(GL_QUADS);
        glTexCoord3fv(t[0]); glVertex3fv(v[0]);
        glTexCoord3fv(t[1]); glVertex3fv(v[1]);
        glTexCoord3fv(t[3]); glVertex3fv(v[3]);
        glTexCoord3fv(t[2]); glVertex3fv(v[2]);
        
        glTexCoord3fv(t[1]); glVertex3fv(v[1]);
        glTexCoord3fv(t[5]); glVertex3fv(v[5]);
        glTexCoord3fv(t[7]); glVertex3fv(v[7]);
        glTexCoord3fv(t[3]); glVertex3fv(v[3]);
        
        glTexCoord3fv(t[4]); glVertex3fv(v[4]);
        glTexCoord3fv(t[6]); glVertex3fv(v[6]);
        glTexCoord3fv(t[7]); glVertex3fv(v[7]);
        glTexCoord3fv(t[5]); glVertex3fv(v[5]);
        
        glTexCoord3fv(t[0]); glVertex3fv(v[0]);
        glTexCoord3fv(t[2]); glVertex3fv(v[2]);
        glTexCoord3fv(t[6]); glVertex3fv(v[6]);
        glTexCoord3fv(t[4]); glVertex3fv(v[4]);
        
        glTexCoord3fv(t[0]); glVertex3fv(v[0]);
        glTexCoord3fv(t[4]); glVertex3fv(v[4]);
        glTexCoord3fv(t[5]); glVertex3fv(v[5]);
        glTexCoord3fv(t[1]); glVertex3fv(v[1]);
        
        glTexCoord3fv(t[2]); glVertex3fv(v[2]);
        glTexCoord3fv(t[3]); glVertex3fv(v[3]);
        glTexCoord3fv(t[7]); glVertex3fv(v[7]);
        glTexCoord3fv(t[6]); glVertex3fv(v[6]);
    glEnd();      

    glDisable(GL_CULL_FACE);
    
    TurnOffTextureAndPrograms();
    
    glDisable(GL_BLEND);
}


void cxVolume::Draw2DSlice(int nSliceAxis)
{
    CreateTfTex();

    CreateDataTex();
    CreateIndexDataTex();
    CreateGridTex();
    
    float width = m_pVisView->w();
    float height = m_pVisView->h();
    
    glUseProgram(m_nVolProgram);    
    glUniform1i(glGetUniformLocation(m_nVolProgram, "volumeTex"), 0);    
    glUniform1i(glGetUniformLocation(m_nVolProgram, "backTex"), 1);   
    glUniform1i(glGetUniformLocation(m_nVolProgram, "tfTex"), 2);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexX"), 3);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexY"), 4);
    glUniform1i(glGetUniformLocation(m_nVolProgram, "gridTexZ"), 5);

    glUniform1f(glGetUniformLocation(m_nVolProgram, "screenWidth"), width);
    glUniform1f(glGetUniformLocation(m_nVolProgram, "screenHeight"), height);
    glUniform1f(glGetUniformLocation(m_nVolProgram, "sampleSpacing"), m_pVisStatus->m_fSampleSpacing);
    glUniform4f(glGetUniformLocation(m_nVolProgram, "lightPar"), 
                m_pVisStatus->m_fLightPar[0], m_pVisStatus->m_fLightPar[1], 
                m_pVisStatus->m_fLightPar[2], m_pVisStatus->m_fLightPar[3]);
    glUniform3f(glGetUniformLocation(m_nVolProgram, "eyePos"), m_vEye[0], m_vEye[1], m_vEye[2]);
        
    float centralDifferenceSpacing[3];    
    for(int i = 0; i < 3; i++)
        centralDifferenceSpacing[i] = 1.0 / m_vSize[i];

    glUniform3f(glGetUniformLocation(m_nVolProgram, "centralDifferenceSpacing"), 
                centralDifferenceSpacing[0],centralDifferenceSpacing[1],centralDifferenceSpacing[2]);    
    
    glUniform1i(glGetUniformLocation(m_nVolProgram, "drawSlice"), 1);

    float x, y, z, max;

    
    if (nSliceAxis == SLICE_X_AXIS) {
        max = m_vSize[1] > m_vSize[2] ? m_vSize[1] : m_vSize[2];        
        y = 0.75;//m_vSize[1] / max;
        z = 0.75;//m_vSize[2] / max;
        
        float x_pos = 0.5 + m_pVisStatus->m_fSlicePosX * 0.5;
        glBegin(GL_QUADS);
            glTexCoord3f(x_pos, 0, 0);
            glVertex2f(-y, -z);
            glTexCoord3f(x_pos, 1, 0);
            glVertex2f(y, -z);
            glTexCoord3f(x_pos, 1, 1);
            glVertex2f(y, z);
            glTexCoord3f(x_pos, 0, 1);
            glVertex2f(-y, z);
        glEnd();

    }

    if (nSliceAxis == SLICE_Y_AXIS) {
        max = m_vSize[0] > m_vSize[2] ? m_vSize[0] : m_vSize[2];        
        x = 0.75; //m_vSize[0] / max;
        z = 0.75; //m_vSize[2] / max;
        
        float y_pos = 0.5 + m_pVisStatus->m_fSlicePosY * 0.5;
        glBegin(GL_QUADS);
            glTexCoord3f(0, y_pos, 0);
            glVertex2f(-x, -z);
            glTexCoord3f(1, y_pos, 0);
            glVertex2f(x, -z);
            glTexCoord3f(1, y_pos, 1);
            glVertex2f(x, z);
            glTexCoord3f(0, y_pos, 1);
            glVertex2f(-x, z);
        glEnd();

    }


    if (nSliceAxis == SLICE_Z_AXIS) {
        max = m_vSize[0] > m_vSize[1] ? m_vSize[0] : m_vSize[1];        
        x = 0.75; //m_vSize[0] / max;
        y = 0.75; //m_vSize[1] / max;
        
        float z_pos = 0.5 + m_pVisStatus->m_fSlicePosZ * 0.5;
        glBegin(GL_QUADS);
            glTexCoord3f(0, 0, z_pos);
            glVertex2f(-x, -y);
            glTexCoord3f(1, 0, z_pos);
            glVertex2f(x, -y);
            glTexCoord3f(1, 1, z_pos);
            glVertex2f(x, y);
            glTexCoord3f(0, 1, z_pos);
            glVertex2f(-x, y);
        glEnd();
    }

    TurnOffTextureAndPrograms();
}

void cxVolume::Draw2DSliceBoundary()
{
    glPushMatrix();

    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glLineWidth(2.0);
    
    glColor3f(1.0, 1.0, 0.0);
    
    float x = m_vSize[0];
    float y = m_vSize[1];
    float z = m_vSize[2];
    
    if (m_nSliceAxis == SLICE_X_AXIS) {
        x = (m_pVisStatus->m_fSlicePosX + 1 ) * 0.5 * m_vSize[0];
        
        glBegin(GL_LINE_LOOP);
            glVertex3f(x, 0, 0);
            glVertex3f(x, y, 0);
            glVertex3f(x, y, z);
            glVertex3f(x, 0, z);
        glEnd();
    }
    
    if (m_nSliceAxis == SLICE_Y_AXIS) {
        y = (m_pVisStatus->m_fSlicePosY + 1 ) * 0.5 * m_vSize[1];
        
        glBegin(GL_LINE_LOOP);
            glVertex3f(0, y, 0);
            glVertex3f(x, y, 0);
            glVertex3f(x, y, z);
            glVertex3f(0, y, z);
        glEnd();
    }
    
    if (m_nSliceAxis == SLICE_Z_AXIS) {
        z = (m_pVisStatus->m_fSlicePosZ + 1 ) * 0.5 * m_vSize[2];
        
        glBegin(GL_LINE_LOOP);
            glVertex3f(0, 0, z);
            glVertex3f(x, 0, z);
            glVertex3f(x, y, z);
            glVertex3f(0, y, z);
        glEnd();
    }
    

    glPopMatrix();
    glEnable(GL_DEPTH_TEST);
}

void cxVolume::SetTimePeriod(int time_in, int time_out)
{
	m_time_in = time_in;
	m_time_out = time_out; 
}
 
void cxVolume::SetCurVar(char* varname)
{ 
	strcpy(m_curnetcdf_var, varname);
}

void cxVolume::SetYstop(int size) 
{ 
	m_stopIndY  = size + m_startIndY; 
	m_IndYsize = size;
}
    void cxVolume::SetXstop(int size) 
{ 
	m_stopIndX  = size + m_startIndX; 
	m_IndXsize = size;
} 
    
void cxVolume::SetYstart(int start) 
{ 
	m_startIndY = start;
	m_stopIndY = m_IndYsize + start; 
}

void cxVolume::SetXstart(int start) 
{ 
	m_startIndX = start;
	m_stopIndX = m_IndXsize + start; 
}