#ifndef MARCHINGSQUARES_H
#define MARCHINGSQUARES_H

class MarchingSquares
{
	MarchingSquares();
	~MarchingSquares();
};

#endif //MARCHINGSQUARES_H