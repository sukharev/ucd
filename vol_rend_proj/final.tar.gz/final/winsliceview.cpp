//
// C++ Implementation: winsliceview
//
// Description: 
//
//
// Author: Hongfeng Yu <hfyu@ucdavis.edu>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "GL/glew.h"
#include "winsliceview.h"
#include <GL/glu.h>
#include <FL/glut.H>

#define TEXTSIZE 12

WinSliceMain::WinSliceMain(int x,int y,int w,int h,const char *l)
{
    GenWindow(x, y, w, h, l);

}

WinSliceMain::~WinSliceMain()
{

}

void WinSliceMain::GenWindow(int x,int y,int w,int h,const char *l)
{
    m_pMainWin = new Fl_Window(x, y, w, h, l);
    m_pMainWin->user_data((void*)(this));
   
    Fl_Group* m_gGroupB = new Fl_Group(0, 0, w, 30);
    m_gGroupB->user_data((void*)(this));
    m_gGroupB->box(FL_THIN_UP_FRAME);
    m_pRoundA = new Fl_Round_Button(m_gGroupB->x() + 3, 
				    m_gGroupB->y() + 3, 
				    70, 30, "Slice X");
    m_pRoundA->type(102);
    m_pRoundA->down_box(FL_ROUND_DOWN_BOX);
    m_pRoundA->callback((Fl_Callback *)cb_RadioA);
      		
    m_pRoundB = new Fl_Round_Button(m_gGroupB->x() + 76, 
	        		    m_gGroupB->y() + 3, 
				    70, 30, "Slice Y");
    m_pRoundB->type(102);
    m_pRoundB->down_box(FL_ROUND_DOWN_BOX);
    m_pRoundB->callback((Fl_Callback *)cb_RadioB);
      	
    m_pRoundC = new Fl_Round_Button(m_gGroupB->x() + 76*2, 
			 	    m_gGroupB->y() + 3, 
				    70, 30, "Slice Z");
    m_pRoundC->type(102);
    m_pRoundC->down_box(FL_ROUND_DOWN_BOX);
    m_pRoundC->callback((Fl_Callback *)cb_RadioC);
    m_gGroupB->end();

    //m_pSliceView = new WinSliceView(0, 0, w, h-30);
    m_pSliceView = new WinSliceView(0, 47, w, h-80);
    m_pSliceView->mode(FL_ALPHA | FL_RGB | FL_DOUBLE | FL_DEPTH);
    m_pSliceView->end();

    m_pSlider = new Fl_Value_Slider(5, h - 25, w - 10, 20);
    m_pSlider->align(FL_ALIGN_TOP_LEFT);
    m_pSlider->labelsize(TEXTSIZE);
    m_pSlider->type(FL_HOR_NICE_SLIDER);
    m_pSlider->range(-1.0, 1.0);
    m_pSlider->value(0.0);
    m_pSlider->step(0.01);   
    m_pSlider->when(FL_WHEN_CHANGED | FL_WHEN_RELEASE);
    m_pSlider->callback((Fl_Callback *)cb_SliderA);
    
    
    m_pMainWin->end();
	m_pMainWin->resizable(NULL);
}


void WinSliceMain::show(int argc, char **argv)
{    
    m_pMainWin->show(argc,argv);
    m_pSliceView->show(argc,argv);
}


inline void WinSliceMain::cb_SliderA_i(Fl_Value_Slider* o, void* v)
{
    if(m_pSliceView == NULL || m_pSliceView->m_pVolume == NULL)
        return;
    
    float pos = o->value();
    
    switch(m_pSliceView->m_nAxis){
        case SLICE_X_AXIS : m_pSliceView->m_pVolume->m_pVisStatus->m_fSlicePosX = pos;
                            break;
        case SLICE_Y_AXIS : m_pSliceView->m_pVolume->m_pVisStatus->m_fSlicePosY = pos;
                            break;
        case SLICE_Z_AXIS : m_pSliceView->m_pVolume->m_pVisStatus->m_fSlicePosZ = pos;
                            break;
    }
        
    
    if (Fl::event_button1()) {
        m_pSliceView->m_pVolume->m_bDraw2DSliceBoundary = true;
        m_pSliceView->m_pVolume->SetSliceAxis(m_pSliceView->m_nAxis);
    }else
        m_pSliceView->m_pVolume->m_bDraw2DSliceBoundary = false;
        
    m_pSliceView->m_pVolume->ReDraw();
}  


void WinSliceMain::cb_SliderA(Fl_Value_Slider* o, void* v)
{
  ((WinSliceMain*)(o->parent()->user_data()))->cb_SliderA_i(o,v);
}

void WinSliceMain::cb_RadioA_i(Fl_Round_Button* o, void*)
{
	if(	m_pSliceView == NULL || m_pSliceView->m_pVolume == NULL)
		return;
	SetVolume(m_pSliceView->m_pVolume, SLICE_X_AXIS);
	m_pSliceView->m_pVolume->ReDraw();
    	//SaveConfig();	
}

void WinSliceMain::cb_RadioA(Fl_Round_Button* o, void* v) {
  ((WinSliceMain*)(o->parent()->user_data()))->cb_RadioA_i(o,v);
}

void WinSliceMain::cb_RadioB_i(Fl_Round_Button* o, void*)
{
	if(m_pSliceView == NULL || m_pSliceView->m_pVolume == NULL)
		return;
	SetVolume(m_pSliceView->m_pVolume, SLICE_Y_AXIS);
	m_pSliceView->m_pVolume->ReDraw();
    	//SaveConfig();	
}

void WinSliceMain::cb_RadioB(Fl_Round_Button* o, void* v) {
  ((WinSliceMain*)(o->parent()->user_data()))->cb_RadioB_i(o,v);
}

void WinSliceMain::cb_RadioC_i(Fl_Round_Button* o, void*)
{
	if(m_pSliceView == NULL || m_pSliceView->m_pVolume == NULL)
		return;
	SetVolume(m_pSliceView->m_pVolume, SLICE_Z_AXIS);
	m_pSliceView->m_pVolume->ReDraw();
    	//SaveConfig();	
}

void WinSliceMain::cb_RadioC(Fl_Round_Button* o, void* v) {
  ((WinSliceMain*)(o->parent()->user_data()))->cb_RadioC_i(o,v);
}


WinSliceView::WinSliceView(int x,int y,int w,int h,const char *l):Fl_Gl_Window(x,y,w,h,l)
{
    m_pVolume = NULL;
    m_nAxis = SLICE_X_AXIS;
    m_bBlack = true;
}


WinSliceView::~WinSliceView()
{

}

void WinSliceView::draw()
{
	if(!valid())
	{
        glViewport(0,0,w(),h());   
         
        GLenum err = glewInit();
        if (GLEW_OK != err)
        {
            // Problem: glewInit failed, something is seriously wrong.
            fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
        }
/* 
         // verify FBOs are supported (otherwise we get FuBar'd Objects)
        if (!glutExtensionSupported ("GL_EXT_framebuffer_object") )
        {
            cerr << "FBO extension unsupported" << endl;
            //exit (1);
        }
*/
	}

	// Set background color
	// Set background color
    if (m_bBlack)   
       glClearColor( 0, 0, 0, 1 );
    else
       glClearColor( 1, 1, 1, 1 );

    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    if (m_pVolume != NULL) {
        //m_pVolume->SetSliceAxis(m_nAxis); 
        m_pVolume->Draw(DRAW_2D_SLICE, m_nAxis);
    }
}