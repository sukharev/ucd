


//#include <FL/glut.H>
#include <iostream>
#include <fstream>
#include <assert.h>
#include "parcrd.h"
#include <FL/gl.h>

#define TEXTSIZE 12

using namespace std;

PCoord::PCoord(int X,int Y,int W,int H, cxVolume * pVolume, int sample) : Fl_Widget(X,Y,W,H)
{
	m_xor = false;
	m_translucent = false;

	m_init = false;
	//m_data = NULL;

	m_windowWidth = w();
	m_windowHeight = h();
	
	m_bg_color.R = m_bg_color.G = m_bg_color.B = 0.0;

	m_netcdf = NULL;
	m_numvars = 0;
	m_datautils = NULL;
	m_data = NULL;
	m_sample = sample;
	m_pVolume = pVolume;
}

PCoord::~PCoord()
{
}

void PCoord::draw()
{
	gl_start();
	fl_clip(x(),y(),w(),h());
	fl_color(FL_DARK3);
	fl_push_matrix();
	
	
	SetDisplaySize(w(), h()-y());
	Display();
	
	fl_line_style(FL_SOLID, 1);
	
	fl_pop_matrix();
	fl_pop_clip();
	
	gl_finish();
}

void PCoord::ChangeDataSize(int new_start, int new_count, char axis)
{
	int out_count = new_count;
	if(m_netcdf && m_datautils){
		if(!m_datautils->ChangeDataSize(new_start, new_count, axis, &out_count))
			cerr << "TODO: change the slider position back!\n";
		m_data = m_datautils->ReadVarData(0,1,true, m_sample);
	}
}

bool PCoord::InitData(int sample)
{
	if(sample != -1)
		m_sample = sample;
	//m_data = data;
	if(m_netcdf) {
		if(m_init && m_datautils && m_fltr){
			m_data = m_datautils->ReadVarData(0,1,true, sample);
		}
		else{
			m_fltr = new Filter();
			m_fltr->m_dim = 4;
			m_datautils = new NetCDFUtils(m_netcdf, m_fltr);
			m_data = m_datautils->ReadVarData(0,1,true, sample);
			m_numvars = m_datautils->get_num_vars();
			m_init = true;
		}
	}
	return m_init; 
}

void PCoord::DrawAxes()
{
    Color c(1.0,0.0,0.0);

    SetForeground(c, 1.0);
    int i;
    for (i=0; i<m_numvars; i++) {
        double x = XMap(i);
        DrawLine(x, y()+10, x, m_windowHeight + y()-20);
    }

    float dimwidth = m_windowWidth/m_numvars;
	

    for (i=0; i<m_numvars; i++)
    {
        float x = XMap(i) + 24;
        DrawConfinedString(x, y()+100 ,m_datautils->names[i],0);

        // Draw the MAX values of the dimension
		char buf[50];
        sprintf(buf, "%.08f", m_datautils->dim_max[i]);
        DrawConfinedString(x, m_windowHeight+y(),buf,0);

        // Draw the MIN values of the dimension
        sprintf(buf, "%.08f", m_datautils->dim_min[i]);
        DrawConfinedString(x, y() ,buf,0);
    }
    // Flush drawing commands
    //glutSwapBuffers();
}

void PCoord::DrawData()
{
}


//////////////////////////////////////////////////////
// utilities

void PCoord::BeginDraw()
{

    if (m_xor == true)
    {
        // Setup XOR drawing mode
        glEnable(GL_COLOR_LOGIC_OP);
        glLogicOp(GL_INVERT);
        glDrawBuffer(GL_FRONT);
    } else {
        glColor4f(m_fg_color.R, m_fg_color.G, m_fg_color.B, m_alpha );
    }

    if (m_translucent == true) // && asize != 0)
    {
        // Turn on Translucency
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    }
/*
    if (m_flatcolor == False)  {
        // Turn on color interpolation
        glShadeModel(GL_SMOOTH);
    } else {
        glShadeModel(GL_FLAT);
    }
*/


}

void PCoord::EndDraw()
{
    if (m_xor == true) {
        glDisable(GL_COLOR_LOGIC_OP);
        glDrawBuffer(GL_BACK);
    }
    if (m_translucent == true) { // && asize != 0)
        glDisable(GL_BLEND);
    }
/*
    if (m_flatcolor == False) {
        glShadeModel(GL_FLAT);
    }
*/
}


void PCoord::DrawLine( float x1, float y1, float x2, float y2)
{
    BeginDraw();
	//glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
    glVertex2f(x1,y1);
    glVertex2f(x2,y2);
	glEnd();
    EndDraw();
}

void PCoord::Display()
{

    if (!m_data) {
	if(!InitData(m_sample))
		return;
    }

//m_numvars = 2;
/*
    canvas->SetTopLeftOrigin();
    grCanvas::grResizeMainCanvas(canvas);
    canvas->SetBackground(interface_color[BG]);
*/
    //glClearColor(m_bg_color.R,m_bg_color.G,m_bg_color.B,0);
    glClear(GL_COLOR_BUFFER_BIT);
	
	//color(m_bg_color.R,m_bg_color.G,m_bg_color.B);

/*
    DrawParcoordBrushes(canvas);

    ARR<Vec2> poly(dataset->dims);
    ARR<float> data(dataset->dims);
*/
    // first draw all points in the data color
    //
    //Color c(0x61f369);
    //glColor3f(c.R, c.G, c.B );

    glLineWidth(1);
    glShadeModel(GL_FLAT);  // Because each line is the same color.

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.0, 0.4, 0.5, 0.4);

    int size = 0;
    
    for (int i=0; i<m_numvars-1; i++)
    {
	if(m_datautils->m_size[i] > size)
		size = m_datautils->m_size[i];
    }

    for (int j=0; j<size; j++) {
	glBegin(GL_LINE_STRIP);
	for (int i=0; i<m_numvars-1; i++)
	{
		float* data = m_data[i];
		if (!data)
			break;
		if (m_datautils->m_size[i] < 1)
			break;
		int index = m_datautils->GetCoordPosition(i, j);
		glVertex2f( XMap(i), y()+10 + (YMap(i,data[index])) );
		/*
		float* d1 = m_data[i];
		float* d2 = m_data[i+1];
		if (!d1 || !d2 )
			break;
		if (m_datautils->m_size[i] < 1 && m_datautils->m_size[i+1] < 1)
			break;
	
		if(m_datautils->m_size[i] > m_datautils->m_size[i+1])
			size = m_datautils->m_size[i];
		else
			size = m_datautils->m_size[i+1];
		
		//glColor3f(0.0, 0.4, 0.5);//, 0.1 );
		glColor4f(0.0, 0.4, 0.5, 0.2);//, 0.1 );
		
		int d1_j_mod = 0;
		int d2_j_mod = 0;
		for (int j=0; j<size; j++) {
			glBegin(GL_LINE_STRIP);
			//d1_j_mod = j % m_datautils->m_size[i];
			//d2_j_mod = j % m_datautils->m_size[i+1];
			d1_j_mod = m_datautils->GetCoordPosition(i, j);
			d2_j_mod = m_datautils->GetCoordPosition(i+1, j);
			glVertex2f( XMap(i), y()+10 + (YMap(i,d1[d1_j_mod])) );
			glVertex2f( XMap(i+1), y()+10 + (YMap(i+1,d2[d2_j_mod])) );
			glEnd();
		}
		*/
		
	}
	glEnd();
    }
    glDisable(GL_BLEND);

/*
    // now paint all points covered by an operation
    //
    for (i=0; i<dataset->data_size; i++)
    {
        if (dataset->mark[i] == okcdata::DISABLED) continue;
        if (dataset->mark[i] == okcdata::REGULAR) continue;

        dataset->GetData(data, i);

        glColor3f(dataset->color[i].R, dataset->color[i].G, dataset->color[i].B );
        glBegin(GL_LINE_STRIP);

        for (int j=0; j<dataset->dims; j++) {
            glVertex2f( XMAP(j), YMAP(j,data[j]) );
        }
        glEnd();
    }

    // Draw average operations
    for (int op=0; op<num_oper; op++)
    {
        // Check if this operation has OPER_AVERAGE set 
        if (!(brush_ops[op].oper & AVERAGE)) continue;

        ARR<float> average(dataset->dims);
        if (BrushOperCompAverage(op, average)==0) continue;

        glLineWidth(3.0);
        canvas->SetForeground(interface_color[TEXT]);
        DrawParcoordAverage(canvas,average);
    }
*/


    glLineWidth(7);
    glShadeModel(GL_SMOOTH);

    DrawAxes();
}

void PCoord::DrawConfinedString( float x, float y, const char *text, float width)
{
/*
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();    
*/
    gl_font(FL_HELVETICA_BOLD, 9);
    gl_color(FL_WHITE);
    gl_draw(text, x, y);	
    //gl_draw("GG",0,0);
/*    
    glPopMatrix();
    glPopMatrix();
*/
}

void PCoord::DrawString( float x, float y, const char *text, int N )
{
    gl_font(FL_HELVETICA_BOLD, 9);
    gl_color(FL_WHITE);
    gl_draw(text, x, y);
}
/*
void PCoord::DrawString( const char *text, int N )
{
	assert(text);
    if (N<0) N=strlen(text);
	m_font_base = 1000;
    if (m_font_base == 0) return;
    glListBase(m_font_base);
    glCallLists(N,GL_UNSIGNED_BYTE,text);
}
*/


void PCoord::SetForeground( const Color &color, float a )
{
    // Set normal foreground
    m_fg_color = color;
    m_alpha = a;
    if (a!=1.0) m_translucent = true;
    else m_translucent = false;
}

void PCoord::SetForeground( unsigned long color, float a )
{
    SetForeground(Color(color),a);
}
