//
// C++ Interface: winsliceview
//
// Description: 
//
//
// Author: Hongfeng Yu <hfyu@ucdavis.edu>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef WINSLICEVIEW_H
#define WINSLICEVIEW_H

/**
	@author Hongfeng Yu <hfyu@ucdavis.edu>
*/

#include <FL/Fl.H>
#include <FL/Fl_Gl_Window.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Tabs.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Value_Slider.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Round_Button.H>
#include <FL/gl.h>


#include <assert.h>
#include "cxvolume.h"


class WinSliceView : public Fl_Gl_Window
{
public:
    WinSliceView(int x,int y,int w,int h,const char *l=0);

    virtual ~WinSliceView();

private:

    void draw();

public:
    cxVolume * m_pVolume;
    int m_nAxis;
    bool m_bBlack;
    
};

class WinSliceMain
{
public:
    
    WinSliceMain(int x,int y,int w,int h,const char *l=0);
    
    ~WinSliceMain();

    void GenWindow(int x,int y,int w,int h,const char *l=0);

    void show(int argc = 0, char ** argv = NULL);

    void SetVolume(cxVolume * pVolume, int axis)
    {
        if (m_pSliceView != NULL) {
            m_pSliceView->m_pVolume = pVolume; 
            m_pSliceView->m_nAxis = axis;
            pVolume->m_pSliceView[axis - SLICE_X_AXIS] = m_pSliceView;           
        }
           
    }

    //call back function for slider
    inline void cb_SliderA_i(Fl_Value_Slider*, void*);
    static void cb_SliderA(Fl_Value_Slider*, void*);

public:
    inline void cb_RadioA_i(Fl_Round_Button*, void*);
    static void cb_RadioA(Fl_Round_Button*, void*);

    inline void cb_RadioB_i(Fl_Round_Button*, void*);
    static void cb_RadioB(Fl_Round_Button*, void*);

    inline void cb_RadioC_i(Fl_Round_Button*, void*);
    static void cb_RadioC(Fl_Round_Button*, void*);
    
public:

    Fl_Window * m_pMainWin;

    Fl_Value_Slider * m_pSlider;
    
    WinSliceView * m_pSliceView;

    //roundbutton
    Fl_Round_Button *m_pRoundA;
    Fl_Round_Button *m_pRoundB;
    Fl_Round_Button *m_pRoundC;
   
};

#endif
