#include "sv_correlation.h"
#include "GL/glew.h"
#include "GL/gl.h"
#include <fstream>
#include <string>
#include <iomanip>
#include <sstream>
#include <assert.h>
#include <algorithm>
#include <iostream>
#include <iterator>
#include <vector>
#include <math.h>

using namespace std;


SVCorrelation::SVCorrelation(int timestamp)
{
}

SVCorrelation::~SVCorrelation()
{
}

