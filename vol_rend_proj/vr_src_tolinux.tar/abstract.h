#ifndef ABSTRACT_H
#define ABSTRACT_H

class SlaveUI
{
public:
	virtual void AddUI(int n) = 0;
};

#endif //ABSTRACT_H