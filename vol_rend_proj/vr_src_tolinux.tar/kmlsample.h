#ifndef KMLSAMPLE_H
#define KMLSAMPLE_H

#ifndef STANDALONE
int main_cluster(int argc, char **argv);
#endif

#endif //KMLSAMPLE_H